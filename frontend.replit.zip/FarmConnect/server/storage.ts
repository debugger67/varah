import {
  users, type User, type InsertUser,
  farms, type Farm, type InsertFarm,
  crops, type Crop, type InsertCrop,
  markets, type Market, type InsertMarket,
  cropMarkets, type CropMarket, type InsertCropMarket,
  transporters, type Transporter, type InsertTransporter,
  transportPools, type TransportPool, type InsertTransportPool,
  poolMembers, type PoolMember, type InsertPoolMember,
  cropRecommendations, type CropRecommendation, type InsertCropRecommendation,
  mentors, type Mentor, type InsertMentor,
  videos, type Video, type InsertVideo,
  financialTransactions, type FinancialTransaction, type InsertFinancialTransaction,
  weatherAlerts, type WeatherAlert, type InsertWeatherAlert
} from "@shared/schema";

export interface IStorage {
  // User methods
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUser(id: number, user: Partial<User>): Promise<User | undefined>;
  
  // Farm methods
  getFarm(id: number): Promise<Farm | undefined>;
  getFarmsByUserId(userId: number): Promise<Farm[]>;
  createFarm(farm: InsertFarm): Promise<Farm>;
  updateFarm(id: number, farm: Partial<Farm>): Promise<Farm | undefined>;
  
  // Crop methods
  getCrop(id: number): Promise<Crop | undefined>;
  getCropsByFarmId(farmId: number): Promise<Crop[]>;
  createCrop(crop: InsertCrop): Promise<Crop>;
  updateCrop(id: number, crop: Partial<Crop>): Promise<Crop | undefined>;
  
  // Market methods
  getMarket(id: number): Promise<Market | undefined>;
  getMarkets(type?: string): Promise<Market[]>;
  createMarket(market: InsertMarket): Promise<Market>;
  
  // CropMarket methods
  getCropMarket(id: number): Promise<CropMarket | undefined>;
  getCropMarketsByMarketId(marketId: number): Promise<CropMarket[]>;
  getCropMarketsByCropName(cropName: string): Promise<CropMarket[]>;
  createCropMarket(cropMarket: InsertCropMarket): Promise<CropMarket>;
  updateCropMarket(id: number, cropMarket: Partial<CropMarket>): Promise<CropMarket | undefined>;
  
  // Transporter methods
  getTransporter(id: number): Promise<Transporter | undefined>;
  getTransporters(): Promise<Transporter[]>;
  createTransporter(transporter: InsertTransporter): Promise<Transporter>;
  
  // TransportPool methods
  getTransportPool(id: number): Promise<TransportPool | undefined>;
  getTransportPools(cropType?: string): Promise<TransportPool[]>;
  createTransportPool(transportPool: InsertTransportPool): Promise<TransportPool>;
  updateTransportPool(id: number, transportPool: Partial<TransportPool>): Promise<TransportPool | undefined>;
  
  // PoolMember methods
  getPoolMember(id: number): Promise<PoolMember | undefined>;
  getPoolMembersByPoolId(poolId: number): Promise<PoolMember[]>;
  getPoolMembersByUserId(userId: number): Promise<PoolMember[]>;
  createPoolMember(poolMember: InsertPoolMember): Promise<PoolMember>;
  
  // CropRecommendation methods
  getCropRecommendation(id: number): Promise<CropRecommendation | undefined>;
  getCropRecommendations(season?: string): Promise<CropRecommendation[]>;
  createCropRecommendation(cropRecommendation: InsertCropRecommendation): Promise<CropRecommendation>;
  
  // Mentor methods
  getMentor(id: number): Promise<Mentor | undefined>;
  getMentors(): Promise<Mentor[]>;
  createMentor(mentor: InsertMentor): Promise<Mentor>;
  updateMentor(id: number, mentor: Partial<Mentor>): Promise<Mentor | undefined>;
  
  // Video methods
  getVideo(id: number): Promise<Video | undefined>;
  getVideos(): Promise<Video[]>;
  createVideo(video: InsertVideo): Promise<Video>;
  updateVideoViews(id: number): Promise<Video | undefined>;
  
  // FinancialTransaction methods
  getFinancialTransaction(id: number): Promise<FinancialTransaction | undefined>;
  getFinancialTransactionsByUserId(userId: number): Promise<FinancialTransaction[]>;
  createFinancialTransaction(transaction: InsertFinancialTransaction): Promise<FinancialTransaction>;
  
  // WeatherAlert methods
  getWeatherAlert(id: number): Promise<WeatherAlert | undefined>;
  getWeatherAlertsByLocation(location: string): Promise<WeatherAlert[]>;
  createWeatherAlert(alert: InsertWeatherAlert): Promise<WeatherAlert>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private farms: Map<number, Farm>;
  private crops: Map<number, Crop>;
  private markets: Map<number, Market>;
  private cropMarkets: Map<number, CropMarket>;
  private transporters: Map<number, Transporter>;
  private transportPools: Map<number, TransportPool>;
  private poolMembers: Map<number, PoolMember>;
  private cropRecommendations: Map<number, CropRecommendation>;
  private mentors: Map<number, Mentor>;
  private videos: Map<number, Video>;
  private financialTransactions: Map<number, FinancialTransaction>;
  private weatherAlerts: Map<number, WeatherAlert>;
  
  private userIdCounter: number;
  private farmIdCounter: number;
  private cropIdCounter: number;
  private marketIdCounter: number;
  private cropMarketIdCounter: number;
  private transporterIdCounter: number;
  private transportPoolIdCounter: number;
  private poolMemberIdCounter: number;
  private cropRecommendationIdCounter: number;
  private mentorIdCounter: number;
  private videoIdCounter: number;
  private financialTransactionIdCounter: number;
  private weatherAlertIdCounter: number;

  constructor() {
    this.users = new Map();
    this.farms = new Map();
    this.crops = new Map();
    this.markets = new Map();
    this.cropMarkets = new Map();
    this.transporters = new Map();
    this.transportPools = new Map();
    this.poolMembers = new Map();
    this.cropRecommendations = new Map();
    this.mentors = new Map();
    this.videos = new Map();
    this.financialTransactions = new Map();
    this.weatherAlerts = new Map();
    
    this.userIdCounter = 1;
    this.farmIdCounter = 1;
    this.cropIdCounter = 1;
    this.marketIdCounter = 1;
    this.cropMarketIdCounter = 1;
    this.transporterIdCounter = 1;
    this.transportPoolIdCounter = 1;
    this.poolMemberIdCounter = 1;
    this.cropRecommendationIdCounter = 1;
    this.mentorIdCounter = 1;
    this.videoIdCounter = 1;
    this.financialTransactionIdCounter = 1;
    this.weatherAlertIdCounter = 1;
    
    // Initialize with sample data
    this.initializeData();
  }

  private initializeData() {
    // Create sample users
    this.createUser({
      username: "ravipatel",
      password: "password123",
      name: "Ravi Patel",
      farmType: "Wheat & Rice Farmer",
      location: "Amravati",
      state: "Maharashtra",
      district: "Amravati",
      language: "en",
      profileImage: "https://images.unsplash.com/photo-1582440529534-d61bce629def"
    });

    // Create sample markets
    this.createMarket({
      name: "Nagpur Mandi",
      location: "Nagpur",
      state: "Maharashtra",
      district: "Nagpur",
      type: "state",
      demandLevel: "high"
    });
    
    this.createMarket({
      name: "Amravati APMC",
      location: "Amravati",
      state: "Maharashtra",
      district: "Amravati",
      type: "district",
      demandLevel: "medium"
    });
    
    this.createMarket({
      name: "Indore Mandi",
      location: "Indore",
      state: "Madhya Pradesh",
      district: "Indore",
      type: "state",
      demandLevel: "high"
    });

    // Create sample crop markets
    this.createCropMarket({
      marketId: 1,
      cropName: "Soybean",
      price: 4200,
      priceChange: 8,
      availability: "available",
      demandLevel: "high"
    });
    
    this.createCropMarket({
      marketId: 2,
      cropName: "Cotton",
      price: 6800,
      priceChange: -3,
      availability: "available",
      demandLevel: "medium"
    });
    
    this.createCropMarket({
      marketId: 3,
      cropName: "Wheat",
      price: 2050,
      priceChange: 5,
      availability: "available",
      demandLevel: "high"
    });

    // Create sample farms
    this.createFarm({
      userId: 1,
      name: "North Plot",
      location: "Amravati",
      size: 5,
      soilType: "Black Cotton Soil"
    });
    
    this.createFarm({
      userId: 1,
      name: "East Plot",
      location: "Amravati",
      size: 3.5,
      soilType: "Alluvial Soil"
    });

    // Create sample crops
    this.createCrop({
      farmId: 1,
      name: "Wheat",
      variety: "HD-2967",
      status: "growing",
      season: "rabi",
      plantedDate: new Date(2023, 9, 15),
      harvestDate: new Date(2024, 1, 25),
      healthStatus: 90,
      soilHealth: 92,
      waterContent: 85,
      pestControl: 76,
      notes: "Good growth this season"
    });
    
    this.createCrop({
      farmId: 2,
      name: "Rice",
      variety: "Basmati",
      status: "growing",
      season: "kharif",
      plantedDate: new Date(2023, 5, 10),
      harvestDate: new Date(2023, 9, 20),
      healthStatus: 70,
      soilHealth: 68,
      waterContent: 90,
      pestControl: 45,
      notes: "Pest issues observed"
    });

    // Create sample transporters
    this.createTransporter({
      name: "Singh Transport Services",
      capacity: 15,
      ratePerKm: 18,
      contact: "9876543210",
      location: "Amravati",
      available: true
    });
    
    this.createTransporter({
      name: "Kumar Logistics",
      capacity: 8,
      ratePerKm: 15,
      contact: "9876543211",
      location: "Nagpur",
      available: true
    });
    
    this.createTransporter({
      name: "Farmer Cooperative Transport",
      capacity: 12,
      ratePerKm: 13,
      contact: "9876543212",
      location: "Amravati",
      available: true
    });

    // Create sample transport pools
    this.createTransportPool({
      destination: "Indore Mandi",
      departureDate: new Date(2023, 10, 25),
      cropType: "Wheat",
      capacity: 15,
      filledCapacity: 8,
      savingsPercentage: 30
    });
    
    this.createTransportPool({
      destination: "Delhi Market",
      departureDate: new Date(2023, 10, 18),
      cropType: "Rice",
      capacity: 20,
      filledCapacity: 12,
      savingsPercentage: 45
    });

    // Create sample crop recommendations
    this.createCropRecommendation({
      name: "Wheat",
      variety: "HD-2967",
      season: "rabi",
      growingPeriod: "120-135 days",
      waterRequirement: "Medium",
      estimatedYield: "48-52 q/ha",
      marketDemand: "High",
      profitPotential: "High",
      imageUrl: "https://images.unsplash.com/photo-1581515286348-98549702050f"
    });
    
    this.createCropRecommendation({
      name: "Mustard",
      variety: "RH-725",
      season: "rabi",
      growingPeriod: "110-120 days",
      waterRequirement: "Low",
      estimatedYield: "22-25 q/ha",
      marketDemand: "Medium",
      profitPotential: "Medium",
      imageUrl: "https://images.unsplash.com/photo-1595068194527-739532a9cb90"
    });
    
    this.createCropRecommendation({
      name: "Gram",
      variety: "JG-14",
      season: "rabi",
      growingPeriod: "95-110 days",
      waterRequirement: "Low",
      estimatedYield: "18-22 q/ha",
      marketDemand: "High",
      profitPotential: "High",
      imageUrl: "https://images.unsplash.com/photo-1594614271503-a3eba9f4b9c1"
    });

    // Create sample mentors
    this.createMentor({
      name: "Dr. Rajesh Kumar",
      specialization: "Soil Scientist",
      organization: "Punjab Agricultural University",
      qualification: "PhD in Soil Science",
      profileImage: "https://images.unsplash.com/photo-1531427186611-ecfd6d936c79"
    });
    
    this.createMentor({
      name: "Dr. Priya Singh",
      specialization: "Crop Specialist",
      organization: "ICAR",
      qualification: "PhD in Agriculture",
      profileImage: "https://images.unsplash.com/photo-1580489944761-15a19d654956"
    });
    
    this.createMentor({
      name: "Rakesh Verma",
      specialization: "Agribusiness Student",
      organization: "IARI",
      qualification: "MSc in Agriculture",
      profileImage: "https://images.unsplash.com/photo-1568602471122-7832951cc4c5"
    });
    
    // Update mentor status
    this.updateMentor(1, { isOnline: true });

    // Create sample videos
    this.createVideo({
      title: "Advanced Wheat Farming Techniques",
      authorId: 1,
      authorName: "Dr. Sharma",
      authorRole: "Agricultural Scientist",
      thumbnailUrl: "https://images.unsplash.com/photo-1523348837708-15d4a09cfac2",
      duration: "4:25"
    });
    
    this.createVideo({
      title: "Organic Farming Success Story",
      authorId: 1,
      authorName: "Meena Kumari",
      authorRole: "Organic Farmer",
      thumbnailUrl: "https://images.unsplash.com/photo-1569880153113-76e33fc52d5f",
      duration: "8:12"
    });
    
    this.createVideo({
      title: "Market Insights: Where to Sell Your Crops",
      authorId: 1,
      authorName: "Anil Kumar",
      authorRole: "Agricultural Economist",
      thumbnailUrl: "https://images.unsplash.com/photo-1530507629858-e3759ce9cf90",
      duration: "6:48"
    });
    
    // Update video views
    this.updateVideoViews(1);
    this.updateVideoViews(1);
    this.updateVideoViews(1);
    this.updateVideoViews(2);
    this.updateVideoViews(2);
    this.updateVideoViews(3);

    // Create sample financial transactions
    this.createFinancialTransaction({
      userId: 1,
      transactionType: "income",
      category: "Wheat Sale",
      amount: 85400,
      description: "Sale of wheat at Indore Mandi"
    });
    
    this.createFinancialTransaction({
      userId: 1,
      transactionType: "expense",
      category: "Pesticide Purchase",
      amount: 12800,
      description: "Purchase of pesticides for rice crop"
    });
    
    this.createFinancialTransaction({
      userId: 1,
      transactionType: "income",
      category: "Rice Sale",
      amount: 128000,
      description: "Sale of rice at local APMC"
    });

    // Create sample weather alerts
    this.createWeatherAlert({
      location: "Amravati, Maharashtra",
      alert: "Light rain expected tomorrow. Consider postponing pesticide application.",
      severity: "info"
    });
  }

  // User methods
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username
    );
  }

  async createUser(user: InsertUser): Promise<User> {
    const id = this.userIdCounter++;
    const newUser: User = { ...user, id, profileCompleteness: 85, createdAt: new Date() };
    this.users.set(id, newUser);
    return newUser;
  }

  async updateUser(id: number, updates: Partial<User>): Promise<User | undefined> {
    const user = await this.getUser(id);
    if (!user) return undefined;
    
    const updatedUser = { ...user, ...updates };
    this.users.set(id, updatedUser);
    return updatedUser;
  }

  // Farm methods
  async getFarm(id: number): Promise<Farm | undefined> {
    return this.farms.get(id);
  }

  async getFarmsByUserId(userId: number): Promise<Farm[]> {
    return Array.from(this.farms.values()).filter(
      (farm) => farm.userId === userId
    );
  }

  async createFarm(farm: InsertFarm): Promise<Farm> {
    const id = this.farmIdCounter++;
    const newFarm: Farm = { ...farm, id, createdAt: new Date() };
    this.farms.set(id, newFarm);
    return newFarm;
  }

  async updateFarm(id: number, updates: Partial<Farm>): Promise<Farm | undefined> {
    const farm = await this.getFarm(id);
    if (!farm) return undefined;
    
    const updatedFarm = { ...farm, ...updates };
    this.farms.set(id, updatedFarm);
    return updatedFarm;
  }

  // Crop methods
  async getCrop(id: number): Promise<Crop | undefined> {
    return this.crops.get(id);
  }

  async getCropsByFarmId(farmId: number): Promise<Crop[]> {
    return Array.from(this.crops.values()).filter(
      (crop) => crop.farmId === farmId
    );
  }

  async createCrop(crop: InsertCrop): Promise<Crop> {
    const id = this.cropIdCounter++;
    const newCrop: Crop = { ...crop, id, createdAt: new Date() };
    this.crops.set(id, newCrop);
    return newCrop;
  }

  async updateCrop(id: number, updates: Partial<Crop>): Promise<Crop | undefined> {
    const crop = await this.getCrop(id);
    if (!crop) return undefined;
    
    const updatedCrop = { ...crop, ...updates };
    this.crops.set(id, updatedCrop);
    return updatedCrop;
  }

  // Market methods
  async getMarket(id: number): Promise<Market | undefined> {
    return this.markets.get(id);
  }

  async getMarkets(type?: string): Promise<Market[]> {
    const allMarkets = Array.from(this.markets.values());
    if (!type) return allMarkets;
    
    return allMarkets.filter(
      (market) => market.type === type
    );
  }

  async createMarket(market: InsertMarket): Promise<Market> {
    const id = this.marketIdCounter++;
    const newMarket: Market = { ...market, id, createdAt: new Date() };
    this.markets.set(id, newMarket);
    return newMarket;
  }

  // CropMarket methods
  async getCropMarket(id: number): Promise<CropMarket | undefined> {
    return this.cropMarkets.get(id);
  }

  async getCropMarketsByMarketId(marketId: number): Promise<CropMarket[]> {
    return Array.from(this.cropMarkets.values()).filter(
      (cropMarket) => cropMarket.marketId === marketId
    );
  }

  async getCropMarketsByCropName(cropName: string): Promise<CropMarket[]> {
    return Array.from(this.cropMarkets.values()).filter(
      (cropMarket) => cropMarket.cropName === cropName
    );
  }

  async createCropMarket(cropMarket: InsertCropMarket): Promise<CropMarket> {
    const id = this.cropMarketIdCounter++;
    const newCropMarket: CropMarket = { ...cropMarket, id, updatedAt: new Date() };
    this.cropMarkets.set(id, newCropMarket);
    return newCropMarket;
  }

  async updateCropMarket(id: number, updates: Partial<CropMarket>): Promise<CropMarket | undefined> {
    const cropMarket = await this.getCropMarket(id);
    if (!cropMarket) return undefined;
    
    const updatedCropMarket = { ...cropMarket, ...updates, updatedAt: new Date() };
    this.cropMarkets.set(id, updatedCropMarket);
    return updatedCropMarket;
  }

  // Transporter methods
  async getTransporter(id: number): Promise<Transporter | undefined> {
    return this.transporters.get(id);
  }

  async getTransporters(): Promise<Transporter[]> {
    return Array.from(this.transporters.values());
  }

  async createTransporter(transporter: InsertTransporter): Promise<Transporter> {
    const id = this.transporterIdCounter++;
    const newTransporter: Transporter = { ...transporter, id, createdAt: new Date() };
    this.transporters.set(id, newTransporter);
    return newTransporter;
  }

  // TransportPool methods
  async getTransportPool(id: number): Promise<TransportPool | undefined> {
    return this.transportPools.get(id);
  }

  async getTransportPools(cropType?: string): Promise<TransportPool[]> {
    const allPools = Array.from(this.transportPools.values());
    if (!cropType) return allPools;
    
    return allPools.filter(
      (pool) => pool.cropType === cropType
    );
  }

  async createTransportPool(transportPool: InsertTransportPool): Promise<TransportPool> {
    const id = this.transportPoolIdCounter++;
    const newTransportPool: TransportPool = { 
      ...transportPool, 
      id, 
      filledCapacity: 0,
      createdAt: new Date() 
    };
    this.transportPools.set(id, newTransportPool);
    return newTransportPool;
  }

  async updateTransportPool(id: number, updates: Partial<TransportPool>): Promise<TransportPool | undefined> {
    const transportPool = await this.getTransportPool(id);
    if (!transportPool) return undefined;
    
    const updatedTransportPool = { ...transportPool, ...updates };
    this.transportPools.set(id, updatedTransportPool);
    return updatedTransportPool;
  }

  // PoolMember methods
  async getPoolMember(id: number): Promise<PoolMember | undefined> {
    return this.poolMembers.get(id);
  }

  async getPoolMembersByPoolId(poolId: number): Promise<PoolMember[]> {
    return Array.from(this.poolMembers.values()).filter(
      (member) => member.poolId === poolId
    );
  }

  async getPoolMembersByUserId(userId: number): Promise<PoolMember[]> {
    return Array.from(this.poolMembers.values()).filter(
      (member) => member.userId === userId
    );
  }

  async createPoolMember(poolMember: InsertPoolMember): Promise<PoolMember> {
    const id = this.poolMemberIdCounter++;
    const newPoolMember: PoolMember = { ...poolMember, id, createdAt: new Date() };
    this.poolMembers.set(id, newPoolMember);
    
    // Update the pool's filled capacity
    const pool = await this.getTransportPool(poolMember.poolId);
    if (pool) {
      const newFilledCapacity = pool.filledCapacity + poolMember.contribution;
      await this.updateTransportPool(pool.id, { filledCapacity: newFilledCapacity });
    }
    
    return newPoolMember;
  }

  // CropRecommendation methods
  async getCropRecommendation(id: number): Promise<CropRecommendation | undefined> {
    return this.cropRecommendations.get(id);
  }

  async getCropRecommendations(season?: string): Promise<CropRecommendation[]> {
    const allRecommendations = Array.from(this.cropRecommendations.values());
    if (!season) return allRecommendations;
    
    return allRecommendations.filter(
      (recommendation) => recommendation.season === season
    );
  }

  async createCropRecommendation(cropRecommendation: InsertCropRecommendation): Promise<CropRecommendation> {
    const id = this.cropRecommendationIdCounter++;
    const newCropRecommendation: CropRecommendation = { ...cropRecommendation, id, createdAt: new Date() };
    this.cropRecommendations.set(id, newCropRecommendation);
    return newCropRecommendation;
  }

  // Mentor methods
  async getMentor(id: number): Promise<Mentor | undefined> {
    return this.mentors.get(id);
  }

  async getMentors(): Promise<Mentor[]> {
    return Array.from(this.mentors.values());
  }

  async createMentor(mentor: InsertMentor): Promise<Mentor> {
    const id = this.mentorIdCounter++;
    const newMentor: Mentor = { ...mentor, id, isOnline: false, createdAt: new Date() };
    this.mentors.set(id, newMentor);
    return newMentor;
  }

  async updateMentor(id: number, updates: Partial<Mentor>): Promise<Mentor | undefined> {
    const mentor = await this.getMentor(id);
    if (!mentor) return undefined;
    
    const updatedMentor = { ...mentor, ...updates };
    this.mentors.set(id, updatedMentor);
    return updatedMentor;
  }

  // Video methods
  async getVideo(id: number): Promise<Video | undefined> {
    return this.videos.get(id);
  }

  async getVideos(): Promise<Video[]> {
    return Array.from(this.videos.values());
  }

  async createVideo(video: InsertVideo): Promise<Video> {
    const id = this.videoIdCounter++;
    const newVideo: Video = { 
      ...video, 
      id, 
      views: 0,
      uploadedAt: new Date() 
    };
    this.videos.set(id, newVideo);
    return newVideo;
  }

  async updateVideoViews(id: number): Promise<Video | undefined> {
    const video = await this.getVideo(id);
    if (!video) return undefined;
    
    const updatedVideo = { ...video, views: video.views + 1 };
    this.videos.set(id, updatedVideo);
    return updatedVideo;
  }

  // FinancialTransaction methods
  async getFinancialTransaction(id: number): Promise<FinancialTransaction | undefined> {
    return this.financialTransactions.get(id);
  }

  async getFinancialTransactionsByUserId(userId: number): Promise<FinancialTransaction[]> {
    return Array.from(this.financialTransactions.values()).filter(
      (transaction) => transaction.userId === userId
    );
  }

  async createFinancialTransaction(transaction: InsertFinancialTransaction): Promise<FinancialTransaction> {
    const id = this.financialTransactionIdCounter++;
    const newTransaction: FinancialTransaction = { ...transaction, id, date: new Date() };
    this.financialTransactions.set(id, newTransaction);
    return newTransaction;
  }

  // WeatherAlert methods
  async getWeatherAlert(id: number): Promise<WeatherAlert | undefined> {
    return this.weatherAlerts.get(id);
  }

  async getWeatherAlertsByLocation(location: string): Promise<WeatherAlert[]> {
    return Array.from(this.weatherAlerts.values()).filter(
      (alert) => alert.location.includes(location)
    );
  }

  async createWeatherAlert(alert: InsertWeatherAlert): Promise<WeatherAlert> {
    const id = this.weatherAlertIdCounter++;
    const newAlert: WeatherAlert = { ...alert, id, date: new Date() };
    this.weatherAlerts.set(id, newAlert);
    return newAlert;
  }
}

export const storage = new MemStorage();
