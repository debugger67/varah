import type { Express, Request, Response } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import {
  insertUserSchema,
  insertFarmSchema,
  insertCropSchema,
  insertMarketSchema,
  insertCropMarketSchema,
  insertTransporterSchema,
  insertTransportPoolSchema,
  insertPoolMemberSchema,
  insertCropRecommendationSchema,
  insertMentorSchema,
  insertVideoSchema,
  insertFinancialTransactionSchema,
  insertWeatherAlertSchema
} from "@shared/schema";
import { z } from "zod";

export async function registerRoutes(app: Express): Promise<Server> {
  // User routes
  app.get("/api/users/:id", async (req: Request, res: Response) => {
    const { id } = req.params;
    const user = await storage.getUser(Number(id));
    
    if (!user) {
      return res.status(404).json({ message: "User not found" });
    }
    
    res.json(user);
  });
  
  app.post("/api/users", async (req: Request, res: Response) => {
    try {
      const userData = insertUserSchema.parse(req.body);
      const existingUser = await storage.getUserByUsername(userData.username);
      
      if (existingUser) {
        return res.status(409).json({ message: "Username already exists" });
      }
      
      const user = await storage.createUser(userData);
      res.status(201).json(user);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid user data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create user" });
    }
  });
  
  app.patch("/api/users/:id", async (req: Request, res: Response) => {
    try {
      const { id } = req.params;
      const user = await storage.getUser(Number(id));
      
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      
      const updatedUser = await storage.updateUser(Number(id), req.body);
      res.json(updatedUser);
    } catch (error) {
      res.status(500).json({ message: "Failed to update user" });
    }
  });
  
  // Farm routes
  app.get("/api/farms", async (req: Request, res: Response) => {
    const { userId } = req.query;
    
    if (userId) {
      const farms = await storage.getFarmsByUserId(Number(userId));
      return res.json(farms);
    }
    
    // For now, we don't have a getAll method for farms
    res.status(400).json({ message: "userId is required" });
  });
  
  app.get("/api/farms/:id", async (req: Request, res: Response) => {
    const { id } = req.params;
    const farm = await storage.getFarm(Number(id));
    
    if (!farm) {
      return res.status(404).json({ message: "Farm not found" });
    }
    
    res.json(farm);
  });
  
  app.post("/api/farms", async (req: Request, res: Response) => {
    try {
      const farmData = insertFarmSchema.parse(req.body);
      const farm = await storage.createFarm(farmData);
      res.status(201).json(farm);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid farm data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create farm" });
    }
  });
  
  app.patch("/api/farms/:id", async (req: Request, res: Response) => {
    try {
      const { id } = req.params;
      const farm = await storage.getFarm(Number(id));
      
      if (!farm) {
        return res.status(404).json({ message: "Farm not found" });
      }
      
      const updatedFarm = await storage.updateFarm(Number(id), req.body);
      res.json(updatedFarm);
    } catch (error) {
      res.status(500).json({ message: "Failed to update farm" });
    }
  });
  
  // Crop routes
  app.get("/api/crops", async (req: Request, res: Response) => {
    const { farmId } = req.query;
    
    if (farmId) {
      const crops = await storage.getCropsByFarmId(Number(farmId));
      return res.json(crops);
    }
    
    res.status(400).json({ message: "farmId is required" });
  });
  
  app.get("/api/crops/:id", async (req: Request, res: Response) => {
    const { id } = req.params;
    const crop = await storage.getCrop(Number(id));
    
    if (!crop) {
      return res.status(404).json({ message: "Crop not found" });
    }
    
    res.json(crop);
  });
  
  app.post("/api/crops", async (req: Request, res: Response) => {
    try {
      const cropData = insertCropSchema.parse(req.body);
      const crop = await storage.createCrop(cropData);
      res.status(201).json(crop);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid crop data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create crop" });
    }
  });
  
  app.patch("/api/crops/:id", async (req: Request, res: Response) => {
    try {
      const { id } = req.params;
      const crop = await storage.getCrop(Number(id));
      
      if (!crop) {
        return res.status(404).json({ message: "Crop not found" });
      }
      
      const updatedCrop = await storage.updateCrop(Number(id), req.body);
      res.json(updatedCrop);
    } catch (error) {
      res.status(500).json({ message: "Failed to update crop" });
    }
  });
  
  // Market routes
  app.get("/api/markets", async (req: Request, res: Response) => {
    const { type } = req.query;
    
    if (type && typeof type === 'string') {
      const markets = await storage.getMarkets(type);
      return res.json(markets);
    }
    
    const markets = await storage.getMarkets();
    res.json(markets);
  });
  
  app.get("/api/markets/:id", async (req: Request, res: Response) => {
    const { id } = req.params;
    const market = await storage.getMarket(Number(id));
    
    if (!market) {
      return res.status(404).json({ message: "Market not found" });
    }
    
    res.json(market);
  });
  
  app.post("/api/markets", async (req: Request, res: Response) => {
    try {
      const marketData = insertMarketSchema.parse(req.body);
      const market = await storage.createMarket(marketData);
      res.status(201).json(market);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid market data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create market" });
    }
  });
  
  // CropMarket routes
  app.get("/api/crop-markets", async (req: Request, res: Response) => {
    const { marketId, cropName } = req.query;
    
    if (marketId) {
      const cropMarkets = await storage.getCropMarketsByMarketId(Number(marketId));
      return res.json(cropMarkets);
    }
    
    if (cropName && typeof cropName === 'string') {
      const cropMarkets = await storage.getCropMarketsByCropName(cropName);
      return res.json(cropMarkets);
    }
    
    res.status(400).json({ message: "marketId or cropName is required" });
  });
  
  app.get("/api/crop-markets/:id", async (req: Request, res: Response) => {
    const { id } = req.params;
    const cropMarket = await storage.getCropMarket(Number(id));
    
    if (!cropMarket) {
      return res.status(404).json({ message: "Crop market not found" });
    }
    
    res.json(cropMarket);
  });
  
  app.post("/api/crop-markets", async (req: Request, res: Response) => {
    try {
      const cropMarketData = insertCropMarketSchema.parse(req.body);
      const cropMarket = await storage.createCropMarket(cropMarketData);
      res.status(201).json(cropMarket);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid crop market data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create crop market" });
    }
  });
  
  app.patch("/api/crop-markets/:id", async (req: Request, res: Response) => {
    try {
      const { id } = req.params;
      const cropMarket = await storage.getCropMarket(Number(id));
      
      if (!cropMarket) {
        return res.status(404).json({ message: "Crop market not found" });
      }
      
      const updatedCropMarket = await storage.updateCropMarket(Number(id), req.body);
      res.json(updatedCropMarket);
    } catch (error) {
      res.status(500).json({ message: "Failed to update crop market" });
    }
  });
  
  // Transporter routes
  app.get("/api/transporters", async (_req: Request, res: Response) => {
    const transporters = await storage.getTransporters();
    res.json(transporters);
  });
  
  app.get("/api/transporters/:id", async (req: Request, res: Response) => {
    const { id } = req.params;
    const transporter = await storage.getTransporter(Number(id));
    
    if (!transporter) {
      return res.status(404).json({ message: "Transporter not found" });
    }
    
    res.json(transporter);
  });
  
  app.post("/api/transporters", async (req: Request, res: Response) => {
    try {
      const transporterData = insertTransporterSchema.parse(req.body);
      const transporter = await storage.createTransporter(transporterData);
      res.status(201).json(transporter);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid transporter data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create transporter" });
    }
  });
  
  // TransportPool routes
  app.get("/api/transport-pools", async (req: Request, res: Response) => {
    const { cropType } = req.query;
    
    if (cropType && typeof cropType === 'string') {
      const pools = await storage.getTransportPools(cropType);
      return res.json(pools);
    }
    
    const pools = await storage.getTransportPools();
    res.json(pools);
  });
  
  app.get("/api/transport-pools/:id", async (req: Request, res: Response) => {
    const { id } = req.params;
    const pool = await storage.getTransportPool(Number(id));
    
    if (!pool) {
      return res.status(404).json({ message: "Transport pool not found" });
    }
    
    res.json(pool);
  });
  
  app.post("/api/transport-pools", async (req: Request, res: Response) => {
    try {
      const poolData = insertTransportPoolSchema.parse(req.body);
      const pool = await storage.createTransportPool(poolData);
      res.status(201).json(pool);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid transport pool data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create transport pool" });
    }
  });
  
  // PoolMember routes
  app.get("/api/pool-members", async (req: Request, res: Response) => {
    const { poolId, userId } = req.query;
    
    if (poolId) {
      const members = await storage.getPoolMembersByPoolId(Number(poolId));
      return res.json(members);
    }
    
    if (userId) {
      const members = await storage.getPoolMembersByUserId(Number(userId));
      return res.json(members);
    }
    
    res.status(400).json({ message: "poolId or userId is required" });
  });
  
  app.post("/api/pool-members", async (req: Request, res: Response) => {
    try {
      const memberData = insertPoolMemberSchema.parse(req.body);
      const member = await storage.createPoolMember(memberData);
      res.status(201).json(member);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid pool member data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create pool member" });
    }
  });
  
  // CropRecommendation routes
  app.get("/api/crop-recommendations", async (req: Request, res: Response) => {
    const { season } = req.query;
    
    if (season && typeof season === 'string') {
      const recommendations = await storage.getCropRecommendations(season);
      return res.json(recommendations);
    }
    
    const recommendations = await storage.getCropRecommendations();
    res.json(recommendations);
  });
  
  app.get("/api/crop-recommendations/:id", async (req: Request, res: Response) => {
    const { id } = req.params;
    const recommendation = await storage.getCropRecommendation(Number(id));
    
    if (!recommendation) {
      return res.status(404).json({ message: "Crop recommendation not found" });
    }
    
    res.json(recommendation);
  });
  
  app.post("/api/crop-recommendations", async (req: Request, res: Response) => {
    try {
      const recommendationData = insertCropRecommendationSchema.parse(req.body);
      const recommendation = await storage.createCropRecommendation(recommendationData);
      res.status(201).json(recommendation);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid crop recommendation data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create crop recommendation" });
    }
  });
  
  // Mentor routes
  app.get("/api/mentors", async (_req: Request, res: Response) => {
    const mentors = await storage.getMentors();
    res.json(mentors);
  });
  
  app.get("/api/mentors/:id", async (req: Request, res: Response) => {
    const { id } = req.params;
    const mentor = await storage.getMentor(Number(id));
    
    if (!mentor) {
      return res.status(404).json({ message: "Mentor not found" });
    }
    
    res.json(mentor);
  });
  
  app.post("/api/mentors", async (req: Request, res: Response) => {
    try {
      const mentorData = insertMentorSchema.parse(req.body);
      const mentor = await storage.createMentor(mentorData);
      res.status(201).json(mentor);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid mentor data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create mentor" });
    }
  });
  
  app.patch("/api/mentors/:id", async (req: Request, res: Response) => {
    try {
      const { id } = req.params;
      const mentor = await storage.getMentor(Number(id));
      
      if (!mentor) {
        return res.status(404).json({ message: "Mentor not found" });
      }
      
      const updatedMentor = await storage.updateMentor(Number(id), req.body);
      res.json(updatedMentor);
    } catch (error) {
      res.status(500).json({ message: "Failed to update mentor" });
    }
  });
  
  // Video routes
  app.get("/api/videos", async (_req: Request, res: Response) => {
    const videos = await storage.getVideos();
    res.json(videos);
  });
  
  app.get("/api/videos/:id", async (req: Request, res: Response) => {
    const { id } = req.params;
    const video = await storage.getVideo(Number(id));
    
    if (!video) {
      return res.status(404).json({ message: "Video not found" });
    }
    
    res.json(video);
  });
  
  app.post("/api/videos", async (req: Request, res: Response) => {
    try {
      const videoData = insertVideoSchema.parse(req.body);
      const video = await storage.createVideo(videoData);
      res.status(201).json(video);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid video data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create video" });
    }
  });
  
  app.post("/api/videos/:id/view", async (req: Request, res: Response) => {
    const { id } = req.params;
    const video = await storage.getVideo(Number(id));
    
    if (!video) {
      return res.status(404).json({ message: "Video not found" });
    }
    
    const updatedVideo = await storage.updateVideoViews(Number(id));
    res.json(updatedVideo);
  });
  
  // FinancialTransaction routes
  app.get("/api/financial-transactions", async (req: Request, res: Response) => {
    const { userId } = req.query;
    
    if (!userId) {
      return res.status(400).json({ message: "userId is required" });
    }
    
    const transactions = await storage.getFinancialTransactionsByUserId(Number(userId));
    res.json(transactions);
  });
  
  app.get("/api/financial-transactions/:id", async (req: Request, res: Response) => {
    const { id } = req.params;
    const transaction = await storage.getFinancialTransaction(Number(id));
    
    if (!transaction) {
      return res.status(404).json({ message: "Financial transaction not found" });
    }
    
    res.json(transaction);
  });
  
  app.post("/api/financial-transactions", async (req: Request, res: Response) => {
    try {
      const transactionData = insertFinancialTransactionSchema.parse(req.body);
      const transaction = await storage.createFinancialTransaction(transactionData);
      res.status(201).json(transaction);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid financial transaction data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create financial transaction" });
    }
  });
  
  // WeatherAlert routes
  app.get("/api/weather-alerts", async (req: Request, res: Response) => {
    const { location } = req.query;
    
    if (!location || typeof location !== 'string') {
      // Return empty array instead of error for better UI handling
      return res.json([]);
    }
    
    try {
      const alerts = await storage.getWeatherAlertsByLocation(location);
      
      // If no alerts found, return some sample alerts based on location
      if (alerts.length === 0) {
        // Create sample alerts for demo purposes
        const sampleAlerts = [
          {
            id: 1001,
            location: location,
            alert: "Light rain expected in the evening",
            severity: "low",
            date: new Date().toISOString()
          },
          {
            id: 1002,
            location: location,
            alert: "High humidity may affect crop drying",
            severity: "medium",
            date: new Date().toISOString()
          }
        ];
        
        return res.json(sampleAlerts);
      }
      
      res.json(alerts);
    } catch (error) {
      console.error("Error fetching weather alerts:", error);
      // Return empty array instead of error
      res.json([]);
    }
  });
  
  app.get("/api/weather-alerts/:id", async (req: Request, res: Response) => {
    const { id } = req.params;
    const alert = await storage.getWeatherAlert(Number(id));
    
    if (!alert) {
      return res.status(404).json({ message: "Weather alert not found" });
    }
    
    res.json(alert);
  });
  
  app.post("/api/weather-alerts", async (req: Request, res: Response) => {
    try {
      const alertData = insertWeatherAlertSchema.parse(req.body);
      const alert = await storage.createWeatherAlert(alertData);
      res.status(201).json(alert);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid weather alert data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create weather alert" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
