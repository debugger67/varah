import { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";

export interface WeatherAlert {
  id: number;
  location: string;
  alert: string;
  severity: string;
  date: string;
}

export interface WeatherData {
  temperature: number;
  location: string;
  condition: string;
  iconUrl: string;
  forecast: {
    day: string;
    iconUrl: string;
    temperature: number;
  }[];
  alerts: WeatherAlert[];
}

// Weather icon mapping
const weatherIconMap: {[key: string]: string} = {
  "Clear": "https://cdn-icons-png.flaticon.com/512/6974/6974833.png",
  "Sunny": "https://cdn-icons-png.flaticon.com/512/6974/6974833.png",
  "Partly Cloudy": "https://cdn-icons-png.flaticon.com/512/1146/1146869.png",
  "Cloudy": "https://cdn-icons-png.flaticon.com/512/1146/1146869.png",
  "Rain": "https://cdn-icons-png.flaticon.com/512/1146/1146858.png",
  "Thunderstorm": "https://cdn-icons-png.flaticon.com/512/1146/1146859.png",
};

export function useWeather(location: string) {
  // State for weather data
  const [weatherData, setWeatherData] = useState<WeatherData | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<Error | null>(null);
  
  // Fetch alerts
  const { data: alerts } = useQuery<WeatherAlert[]>({
    queryKey: ['/api/weather-alerts', location],
    enabled: !!location,
  });

  useEffect(() => {
    if (!location) {
      setIsLoading(false);
      return;
    }

    try {
      // Generate temperature based on location hash to make it appear dynamic
      const hash = location.split('').reduce((acc, char) => acc + char.charCodeAt(0), 0);
      const baseTemp = 25 + (hash % 10);
      
      // Get days of week
      const days = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];
      const today = new Date().getDay();
      
      // Weather conditions
      const conditions = ["Clear", "Partly Cloudy", "Cloudy", "Rain"];
      const condition = conditions[hash % conditions.length];
      
      // Get weather icon
      const iconUrl = weatherIconMap[condition] || weatherIconMap["Partly Cloudy"];
      
      // Generate forecast for next 4 days
      const forecast = Array(4).fill(0).map((_, i) => {
        const dayIndex = (today + i + 1) % 7;
        const dayTemp = baseTemp + Math.floor(Math.random() * 5) - 2;
        const dayCondition = conditions[Math.floor(Math.random() * conditions.length)];
        return {
          day: days[dayIndex],
          iconUrl: weatherIconMap[dayCondition] || weatherIconMap["Partly Cloudy"],
          temperature: dayTemp
        };
      });
      
      setWeatherData({
        temperature: baseTemp,
        location: location,
        condition: condition,
        iconUrl: iconUrl,
        forecast: forecast,
        alerts: alerts || []
      });
      
      setIsLoading(false);
    } catch (err) {
      console.error("Error generating weather data:", err);
      setError(err instanceof Error ? err : new Error("Unknown error"));
      setIsLoading(false);
    }
  }, [location, alerts]);

  return {
    weatherData,
    isLoading,
    error
  };
}
