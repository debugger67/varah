import { useQuery } from "@tanstack/react-query";
import Header from "@/components/layout/header";
import LeftSidebar from "@/components/layout/left-sidebar";
import RightSidebar from "@/components/layout/right-sidebar";
import BottomNavigation from "@/components/layout/bottom-navigation";
import { useLanguage } from "@/context/language-context";
import { FinanceIcon, MoneyIcon } from "@/lib/icons";
import { Skeleton } from "@/components/ui/skeleton";

export default function Finances() {
  const { t } = useLanguage();
  
  // Get current user
  const { data: user } = useQuery({
    queryKey: ['/api/users/1'],
  });

  // Get financial transactions
  const { data: transactions, isLoading } = useQuery({
    queryKey: ['/api/financial-transactions', { userId: 1 }],
  });

  // Format currency
  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-IN', {
      style: 'currency',
      currency: 'INR',
      maximumFractionDigits: 0
    }).format(amount).replace('₹', '₹');
  };

  // Calculate summary
  const calculateSummary = () => {
    if (!transactions) return { totalRevenue: 0, income: 0, expenses: 0 };
    
    const income = transactions
      .filter((tx: any) => tx.transactionType === 'income')
      .reduce((sum: number, tx: any) => sum + tx.amount, 0);
      
    const expenses = transactions
      .filter((tx: any) => tx.transactionType === 'expense')
      .reduce((sum: number, tx: any) => sum + tx.amount, 0);
      
    return {
      totalRevenue: income - expenses,
      income,
      expenses
    };
  };

  const summary = calculateSummary();

  return (
    <>
      <Header user={user} />
      
      <div className="container mx-auto px-4 md:px-6 pt-4 pb-20 md:pb-8">
        <div className="flex flex-col md:flex-row gap-6">
          
          {/* Left Sidebar */}
          <LeftSidebar user={user} />
          
          {/* Main Content */}
          <main className="flex-1">
            <div className="bg-white rounded-xl shadow-sm p-4 mb-6">
              <h1 className="text-2xl font-bold mb-6 flex items-center">
                <FinanceIcon className="h-6 w-6 mr-2 text-primary" />
                {t("finances")}
              </h1>
              
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
                <div className="bg-neutral-lightest rounded-lg p-4 border border-neutral-light text-center">
                  <MoneyIcon className="h-8 w-8 mx-auto mb-2 text-primary" />
                  <h3 className="text-lg font-semibold">{t("totalRevenue")}</h3>
                  {isLoading ? (
                    <Skeleton className="h-8 w-24 mx-auto mt-2" />
                  ) : (
                    <p className="text-2xl font-bold text-green-600">{formatCurrency(summary.totalRevenue)}</p>
                  )}
                </div>
                
                <div className="bg-neutral-lightest rounded-lg p-4 border border-neutral-light text-center">
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8 mx-auto mb-2 text-green-600" viewBox="0 0 20 20" fill="currentColor">
                    <path fillRule="evenodd" d="M12 7a1 1 0 110-2h5a1 1 0 011 1v5a1 1 0 11-2 0V8.414l-4.293 4.293a1 1 0 01-1.414 0L8 10.414l-4.293 4.293a1 1 0 01-1.414-1.414l5-5a1 1 0 011.414 0L11 10.586 14.586 7H12z" clipRule="evenodd" />
                  </svg>
                  <h3 className="text-lg font-semibold">{t("income")}</h3>
                  {isLoading ? (
                    <Skeleton className="h-8 w-24 mx-auto mt-2" />
                  ) : (
                    <p className="text-2xl font-bold text-green-600">{formatCurrency(summary.income)}</p>
                  )}
                </div>
                
                <div className="bg-neutral-lightest rounded-lg p-4 border border-neutral-light text-center">
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8 mx-auto mb-2 text-red-600" viewBox="0 0 20 20" fill="currentColor">
                    <path fillRule="evenodd" d="M12 13a1 1 0 100 2h5a1 1 0 001-1v-5a1 1 0 10-2 0v2.586l-4.293-4.293a1 1 0 00-1.414 0L8 9.586 3.707 5.293a1 1 0 00-1.414 1.414l5 5a1 1 0 001.414 0L11 9.414 14.586 13H12z" clipRule="evenodd" />
                  </svg>
                  <h3 className="text-lg font-semibold">{t("expenses")}</h3>
                  {isLoading ? (
                    <Skeleton className="h-8 w-24 mx-auto mt-2" />
                  ) : (
                    <p className="text-2xl font-bold text-red-600">{formatCurrency(summary.expenses)}</p>
                  )}
                </div>
              </div>
              
              <h2 className="text-xl font-bold mb-4">{t("recentTransactions")}</h2>
              
              {isLoading ? (
                <div className="space-y-4">
                  {Array(5).fill(0).map((_, i) => (
                    <Skeleton key={i} className="h-16 w-full" />
                  ))}
                </div>
              ) : (
                <div className="bg-neutral-lightest rounded-lg overflow-hidden">
                  <table className="w-full">
                    <thead className="bg-neutral-light">
                      <tr>
                        <th className="text-left py-3 px-4">{t("date")}</th>
                        <th className="text-left py-3 px-4">{t("category")}</th>
                        <th className="text-left py-3 px-4">{t("description")}</th>
                        <th className="text-right py-3 px-4">{t("amount")}</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-neutral-light">
                      {transactions?.map((transaction: any) => (
                        <tr key={transaction.id}>
                          <td className="py-3 px-4">
                            {new Date(transaction.date).toLocaleDateString()}
                          </td>
                          <td className="py-3 px-4 font-medium">{transaction.category}</td>
                          <td className="py-3 px-4">{transaction.description}</td>
                          <td className={`py-3 px-4 text-right font-semibold ${
                            transaction.transactionType === 'income' ? 'text-green-600' : 'text-red-600'
                          }`}>
                            {transaction.transactionType === 'income' ? '+' : '-'}
                            {formatCurrency(transaction.amount)}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
            </div>
          </main>
          
          {/* Right Sidebar */}
          <RightSidebar />
        </div>
      </div>
      
      {/* Bottom Navigation (Mobile) */}
      <BottomNavigation />
    </>
  );
}
