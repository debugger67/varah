import { useQuery } from "@tanstack/react-query";
import Header from "@/components/layout/header";
import LeftSidebar from "@/components/layout/left-sidebar";
import RightSidebar from "@/components/layout/right-sidebar";
import BottomNavigation from "@/components/layout/bottom-navigation";
import MarketSection from "@/components/marketplace/market-section";
import { useLanguage } from "@/context/language-context";

export default function Marketplace() {
  const { t } = useLanguage();
  
  // Get current user
  const { data: user } = useQuery({
    queryKey: ['/api/users/1'],
  });

  return (
    <>
      <Header user={user} />
      
      <div className="container mx-auto px-4 md:px-6 pt-4 pb-20 md:pb-8">
        <div className="flex flex-col md:flex-row gap-6">
          
          {/* Left Sidebar */}
          <LeftSidebar user={user} />
          
          {/* Main Content */}
          <main className="flex-1">
            <div className="bg-white rounded-xl shadow-sm p-4 mb-6">
              <h1 className="text-2xl font-bold mb-6">{t("marketplace")}</h1>
              <p className="mb-4">
                {t("marketplaceDescription") || "Welcome to the Varah marketplace. Connect with buyers, sellers, and transporters to trade your crops efficiently and get the best prices."}
              </p>
            </div>
            
            <MarketSection />
          </main>
          
          {/* Right Sidebar */}
          <RightSidebar />
        </div>
      </div>
      
      {/* Bottom Navigation (Mobile) */}
      <BottomNavigation />
    </>
  );
}
