import { useQuery } from "@tanstack/react-query";
import Header from "@/components/layout/header";
import LeftSidebar from "@/components/layout/left-sidebar";
import RightSidebar from "@/components/layout/right-sidebar";
import BottomNavigation from "@/components/layout/bottom-navigation";
import { ConnectIcon, MentorIcon, SearchIcon } from "@/lib/icons";
import { useLanguage } from "@/context/language-context";
import { Skeleton } from "@/components/ui/skeleton";

export default function Connect() {
  const { t } = useLanguage();
  
  // Get current user
  const { data: user } = useQuery({
    queryKey: ['/api/users/1'],
  });

  // Get mentors
  const { data: mentors, isLoading: mentorsLoading } = useQuery({
    queryKey: ['/api/mentors'],
  });

  return (
    <>
      <Header user={user} />
      
      <div className="container mx-auto px-4 md:px-6 pt-4 pb-20 md:pb-8">
        <div className="flex flex-col md:flex-row gap-6">
          
          {/* Left Sidebar */}
          <LeftSidebar user={user} />
          
          {/* Main Content */}
          <main className="flex-1">
            <div className="bg-white rounded-xl shadow-sm p-4 mb-6">
              <div className="flex items-center justify-between mb-6">
                <h1 className="text-2xl font-bold flex items-center">
                  <ConnectIcon className="h-6 w-6 mr-2 text-primary" />
                  {t("connect")}
                </h1>
                <div className="relative w-64">
                  <input 
                    type="text" 
                    placeholder={t("searchMentors") || "Search for mentors..."}
                    className="w-full border border-neutral-light rounded-full py-2 px-4 pl-10 text-neutral-dark text-sm"
                  />
                  <SearchIcon className="h-4 w-4 absolute left-3 top-2.5 text-neutral-medium" />
                </div>
              </div>
              
              <div className="mb-6">
                <h2 className="text-xl font-bold mb-4 flex items-center">
                  <MentorIcon className="h-5 w-5 mr-2 text-primary" />
                  {t("connectWithMentors")}
                </h2>
                
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                  {mentorsLoading ? (
                    // Loading skeletons
                    Array(6).fill(0).map((_, i) => (
                      <div key={i} className="bg-neutral-lightest rounded-lg p-4 border border-neutral-light">
                        <div className="flex items-start space-x-3">
                          <Skeleton className="w-16 h-16 rounded-full" />
                          <div className="flex-1">
                            <Skeleton className="h-6 w-32 mb-1" />
                            <Skeleton className="h-4 w-full mb-2" />
                            <div className="flex space-x-2">
                              <Skeleton className="h-8 w-20" />
                              <Skeleton className="h-8 w-20" />
                            </div>
                          </div>
                        </div>
                      </div>
                    ))
                  ) : (
                    mentors?.map((mentor: any) => (
                      <div key={mentor.id} className="bg-neutral-lightest rounded-lg p-4 border border-neutral-light">
                        <div className="flex items-start space-x-3">
                          <img 
                            src={mentor.profileImage} 
                            alt={mentor.name} 
                            className="w-16 h-16 rounded-full object-cover" 
                          />
                          <div>
                            <div className="flex items-center mb-1">
                              <h3 className="font-heading font-bold">{mentor.name}</h3>
                              {mentor.isOnline && (
                                <span className="ml-2 bg-green-100 text-green-800 text-xs px-2 py-0.5 rounded-full">
                                  {t("online")}
                                </span>
                              )}
                            </div>
                            <p className="text-sm text-neutral-medium mb-2">
                              {mentor.specialization}, {mentor.organization}
                            </p>
                            <p className="text-xs text-neutral-dark mb-2">
                              {mentor.qualification}
                            </p>
                            <div className="flex space-x-2">
                              <button className="bg-primary text-white text-xs rounded px-3 py-1">
                                {t("connect")}
                              </button>
                              <button className="border border-neutral-medium text-neutral-dark text-xs rounded px-3 py-1">
                                {t("message")}
                              </button>
                            </div>
                          </div>
                        </div>
                      </div>
                    ))
                  )}
                </div>
              </div>
            </div>
          </main>
          
          {/* Right Sidebar */}
          <RightSidebar />
        </div>
      </div>
      
      {/* Bottom Navigation (Mobile) */}
      <BottomNavigation />
    </>
  );
}
