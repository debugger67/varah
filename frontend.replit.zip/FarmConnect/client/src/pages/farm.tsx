import { useQuery } from "@tanstack/react-query";
import Header from "@/components/layout/header";
import LeftSidebar from "@/components/layout/left-sidebar";
import RightSidebar from "@/components/layout/right-sidebar";
import BottomNavigation from "@/components/layout/bottom-navigation";
import CropSuggestions from "@/components/crops/crop-suggestions";
import FarmHealth from "@/components/farm/farm-health";
import { useLanguage } from "@/context/language-context";
import { FarmIcon } from "@/lib/icons";

export default function Farm() {
  const { t } = useLanguage();
  
  // Get current user
  const { data: user } = useQuery({
    queryKey: ['/api/users/1'],
  });

  // Get user farms
  const { data: farms, isLoading: farmsLoading } = useQuery({
    queryKey: ['/api/farms', { userId: 1 }],
  });

  return (
    <>
      <Header user={user} />
      
      <div className="container mx-auto px-4 md:px-6 pt-4 pb-20 md:pb-8">
        <div className="flex flex-col md:flex-row gap-6">
          
          {/* Left Sidebar */}
          <LeftSidebar user={user} />
          
          {/* Main Content */}
          <main className="flex-1">
            <div className="bg-white rounded-xl shadow-sm p-4 mb-6">
              <h1 className="text-2xl font-bold mb-6 flex items-center">
                <FarmIcon className="h-6 w-6 mr-2 text-primary" />
                {t("myFarm")}
              </h1>
              
              {!farmsLoading && farms && (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
                  {farms.map((farm: any) => (
                    <div key={farm.id} className="bg-neutral-lightest rounded-lg p-4 border border-neutral-light">
                      <h2 className="text-xl font-bold mb-2">{farm.name}</h2>
                      <div className="space-y-2 text-sm">
                        <div className="flex justify-between">
                          <span className="text-neutral-medium">{t("location")}:</span>
                          <span className="font-semibold">{farm.location}</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-neutral-medium">{t("size")}:</span>
                          <span className="font-semibold">{farm.size} ha</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-neutral-medium">{t("soilType")}:</span>
                          <span className="font-semibold">{farm.soilType}</span>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              )}
              
              <div className="mb-6">
                <h2 className="text-xl font-bold mb-4">{t("yourFarmHealth")}</h2>
                <FarmHealth />
              </div>
            </div>
            
            <CropSuggestions />
          </main>
          
          {/* Right Sidebar */}
          <RightSidebar />
        </div>
      </div>
      
      {/* Bottom Navigation (Mobile) */}
      <BottomNavigation />
    </>
  );
}
