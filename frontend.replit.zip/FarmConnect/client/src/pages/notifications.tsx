import { useQuery } from "@tanstack/react-query";
import Header from "@/components/layout/header";
import LeftSidebar from "@/components/layout/left-sidebar";
import BottomNavigation from "@/components/layout/bottom-navigation";
import RightSidebar from "@/components/layout/right-sidebar";
import NotificationList from "@/components/notifications/notification-list";
import { useLanguage } from "@/context/language-context";

export default function Notifications() {
  const { t } = useLanguage();

  // In a real app, we'd get userId from auth context
  const userId = 1;
  
  // Fetch user data
  const { data: user } = useQuery({
    queryKey: ['/api/users', userId],
    queryFn: async () => {
      const response = await fetch(`/api/users/${userId}`);
      if (!response.ok) {
        throw new Error('Failed to fetch user data');
      }
      return response.json();
    }
  });

  return (
    <div className="flex flex-col min-h-screen bg-neutral-50">
      <Header user={user} />
      
      <div className="flex flex-1 overflow-hidden">
        <LeftSidebar user={user} />
        
        <main className="flex-1 overflow-y-auto p-4 md:p-6">
          <div className="container mx-auto max-w-5xl">
            <h1 className="text-2xl font-bold mb-6">{t("notifications")}</h1>
            
            <div className="grid grid-cols-1 gap-6">
              <NotificationList />
            </div>
          </div>
        </main>
        
        <RightSidebar />
      </div>
      
      <BottomNavigation />
    </div>
  );
}