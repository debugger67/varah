import { useQuery } from "@tanstack/react-query";
import Header from "@/components/layout/header";
import LeftSidebar from "@/components/layout/left-sidebar";
import RightSidebar from "@/components/layout/right-sidebar";
import BottomNavigation from "@/components/layout/bottom-navigation";
import { VideoPlayIcon, VideosIcon, PlusIcon } from "@/lib/icons";
import { useLanguage } from "@/context/language-context";
import { Skeleton } from "@/components/ui/skeleton";

export default function Videos() {
  const { t } = useLanguage();
  
  // Get current user
  const { data: user } = useQuery({
    queryKey: ['/api/users/1'],
  });

  // Get videos
  const { data: videos, isLoading } = useQuery({
    queryKey: ['/api/videos'],
  });

  return (
    <>
      <Header user={user} />
      
      <div className="container mx-auto px-4 md:px-6 pt-4 pb-20 md:pb-8">
        <div className="flex flex-col md:flex-row gap-6">
          
          {/* Left Sidebar */}
          <LeftSidebar user={user} />
          
          {/* Main Content */}
          <main className="flex-1">
            <div className="bg-white rounded-xl shadow-sm p-4 mb-6">
              <div className="flex justify-between items-center mb-6">
                <h1 className="text-2xl font-bold flex items-center">
                  <VideosIcon className="h-6 w-6 mr-2 text-primary" />
                  {t("videos")}
                </h1>
                <button className="bg-primary text-white rounded-lg px-4 py-2 font-semibold flex items-center">
                  <PlusIcon className="h-5 w-5 mr-1" />
                  {t("uploadVideo") || "Upload Video"}
                </button>
              </div>
              
              <div className="mb-6">
                <h2 className="text-xl font-bold mb-4">{t("latestVideos")}</h2>
                
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                  {isLoading ? (
                    // Loading skeletons
                    Array(6).fill(0).map((_, i) => (
                      <div key={i} className="bg-neutral-lightest rounded-lg overflow-hidden border border-neutral-light">
                        <Skeleton className="w-full h-48" />
                        <div className="p-3">
                          <div className="flex items-start space-x-2 mb-2">
                            <Skeleton className="h-8 w-8 rounded-full" />
                            <div className="flex-1">
                              <Skeleton className="h-5 w-full mb-1" />
                              <Skeleton className="h-4 w-40" />
                            </div>
                          </div>
                          <div className="flex justify-between">
                            <Skeleton className="h-4 w-20" />
                            <Skeleton className="h-4 w-20" />
                          </div>
                        </div>
                      </div>
                    ))
                  ) : (
                    videos?.map((video: any) => (
                      <div key={video.id} className="bg-neutral-lightest rounded-lg overflow-hidden border border-neutral-light">
                        <div className="relative">
                          <img 
                            src={video.thumbnailUrl} 
                            className="w-full h-48 object-cover" 
                            alt={video.title} 
                          />
                          <div className="absolute inset-0 flex items-center justify-center">
                            <button className="bg-primary bg-opacity-80 rounded-full p-3">
                              <VideoPlayIcon className="h-8 w-8 text-white" />
                            </button>
                          </div>
                          <div className="absolute bottom-0 right-0 bg-primary text-white text-xs px-2 py-1 m-2 rounded">
                            {video.duration}
                          </div>
                        </div>
                        <div className="p-3">
                          <div className="flex items-start space-x-2 mb-2">
                            <img 
                              src="https://images.unsplash.com/photo-1550345332-09e3ac987658" 
                              className="w-8 h-8 rounded-full object-cover" 
                              alt={video.authorName} 
                            />
                            <div>
                              <h4 className="font-heading font-bold">{video.title}</h4>
                              <p className="text-xs text-neutral-medium">{video.authorName} • {video.authorRole}</p>
                            </div>
                          </div>
                          <div className="flex justify-between text-xs text-neutral-medium">
                            <span>{video.views}K {t("views")}</span>
                            <span>
                              {Math.floor((new Date().getTime() - new Date(video.uploadedAt).getTime()) / (1000 * 60 * 60 * 24))} {t("daysAgo")}
                            </span>
                          </div>
                        </div>
                      </div>
                    ))
                  )}
                </div>
              </div>
            </div>
          </main>
          
          {/* Right Sidebar */}
          <RightSidebar />
        </div>
      </div>
      
      {/* Bottom Navigation (Mobile) */}
      <BottomNavigation />
    </>
  );
}
