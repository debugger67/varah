import { useLanguage } from "@/context/language-context";
import { WeatherIcon } from "@/lib/icons";
import { useWeather } from "@/hooks/use-weather";
import { Skeleton } from "@/components/ui/skeleton";

interface WeatherWidgetProps {
  location: string;
}

export default function WeatherWidget({ location }: WeatherWidgetProps) {
  const { t } = useLanguage();
  const { weatherData, isLoading, error } = useWeather(location);
  
  if (error) {
    return (
      <div className="bg-white rounded-xl shadow-sm p-4">
        <h3 className="text-lg font-heading font-bold mb-3 flex items-center">
          <WeatherIcon className="h-5 w-5 mr-2 text-accent" />
          {t("weatherAlert")}
        </h3>
        <div className="bg-red-100 p-4 rounded-lg">
          <p className="text-red-700">Failed to load weather data</p>
        </div>
      </div>
    );
  }

  if (isLoading || !weatherData) {
    return (
      <div className="bg-white rounded-xl shadow-sm p-4">
        <h3 className="text-lg font-heading font-bold mb-3 flex items-center">
          <WeatherIcon className="h-5 w-5 mr-2 text-accent" />
          {t("weatherAlert")}
        </h3>
        <div className="flex items-center justify-between mb-3">
          <Skeleton className="h-16 w-32" />
          <Skeleton className="h-12 w-12 rounded-full" />
        </div>
        <Skeleton className="h-16 w-full mb-3" />
        <div className="flex justify-between">
          {Array(4).fill(0).map((_, i) => (
            <Skeleton key={i} className="h-16 w-14" />
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="bg-white rounded-xl shadow-sm p-4">
      <h3 className="text-lg font-heading font-bold mb-3 flex items-center">
        <WeatherIcon className="h-5 w-5 mr-2 text-accent" />
        {t("weatherAlert")}
      </h3>
      <div className="flex items-center justify-between mb-3">
        <div>
          <div className="text-3xl font-bold">{weatherData.temperature}°C</div>
          <div className="text-sm text-neutral-medium">{weatherData.location}</div>
        </div>
        <img 
          src={weatherData.iconUrl} 
          alt={weatherData.condition} 
          className="w-12 h-12 object-cover rounded" 
        />
      </div>
      
      {weatherData.alerts && weatherData.alerts.length > 0 && (
        <div className="bg-accent bg-opacity-10 border-l-4 border-accent p-3 rounded-r-lg mb-3">
          <p className="text-accent-dark text-sm">
            <strong>Alert:</strong> {weatherData.alerts[0]?.alert}
          </p>
        </div>
      )}
      
      <div className="flex justify-between text-sm text-neutral-dark">
        {weatherData.forecast.map((day, index) => (
          <div key={index} className="text-center">
            <div>{day.day}</div>
            <img 
              src={day.iconUrl} 
              alt="Weather Icon" 
              className="w-8 h-8 mx-auto my-1 object-cover rounded"
            />
            <div>{day.temperature}°</div>
          </div>
        ))}
      </div>
    </div>
  );
}
