import { SVGProps } from 'react';

interface LeafLogoProps extends SVGProps<SVGSVGElement> {
  variant?: 'default' | 'small' | 'large';
}

export function LeafLogo({ 
  variant = 'default', 
  className = '', 
  ...props 
}: LeafLogoProps) {
  // Define sizes based on variant
  const sizes = {
    small: { width: 24, height: 24 },
    default: { width: 32, height: 32 },
    large: { width: 48, height: 48 },
  };
  
  const { width, height } = sizes[variant];
  
  return (
    <svg
      width={width}
      height={height}
      viewBox="0 0 64 64"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
      {...props}
    >
      {/* First Leaf */}
      <g transform="translate(2, 0)">
        {/* Leaf shape */}
        <path
          d="M40 8C26.9 8 18 18 10 28C10 20 14 12 20 8"
          stroke="#2E7D32"
          strokeWidth="3"
          strokeLinecap="round"
          strokeLinejoin="round"
        />
        <path
          d="M40 8C40 18 36 28 26 36C18 42 10 42 10 42"
          stroke="#2E7D32"
          strokeWidth="3"
          strokeLinecap="round"
          strokeLinejoin="round"
        />
        <path
          d="M40 8C30 16 18 19 10 28"
          stroke="#2E7D32"
          strokeWidth="3"
          strokeLinecap="round"
          strokeLinejoin="round"
        />
        {/* Fill gradient */}
        <path
          d="M40 8C30 16 18 19 10 28C10 20 14 12 20 8M40 8C40 18 36 28 26 36C18 42 10 42 10 42M40 8C26.9 8 18 18 10 28"
          fill="url(#leaf1-gradient)"
        />
      </g>

      {/* Second Leaf */}
      <g transform="translate(14, 8) scale(0.85)">
        {/* Leaf shape */}
        <path
          d="M40 8C26.9 8 18 18 10 28C10 20 14 12 20 8"
          stroke="#388E3C"
          strokeWidth="3"
          strokeLinecap="round"
          strokeLinejoin="round"
        />
        <path
          d="M40 8C40 18 36 28 26 36C18 42 10 42 10 42"
          stroke="#388E3C"
          strokeWidth="3"
          strokeLinecap="round"
          strokeLinejoin="round"
        />
        <path
          d="M40 8C30 16 18 19 10 28"
          stroke="#388E3C"
          strokeWidth="3"
          strokeLinecap="round"
          strokeLinejoin="round"
        />
        {/* Fill gradient */}
        <path
          d="M40 8C30 16 18 19 10 28C10 20 14 12 20 8M40 8C40 18 36 28 26 36C18 42 10 42 10 42M40 8C26.9 8 18 18 10 28"
          fill="url(#leaf2-gradient)"
        />
      </g>

      {/* Stem */}
      <path
        d="M26 40C26 44 26 52 26 54"
        stroke="#2E7D32"
        strokeWidth="3"
        strokeLinecap="round"
      />

      {/* Define gradients */}
      <defs>
        <linearGradient id="leaf1-gradient" x1="10" y1="42" x2="40" y2="8" gradientUnits="userSpaceOnUse">
          <stop offset="0" stopColor="#81C784" />
          <stop offset="0.5" stopColor="#4CAF50" />
          <stop offset="1" stopColor="#2E7D32" />
        </linearGradient>
        <linearGradient id="leaf2-gradient" x1="10" y1="42" x2="40" y2="8" gradientUnits="userSpaceOnUse">
          <stop offset="0" stopColor="#A5D6A7" />
          <stop offset="0.5" stopColor="#66BB6A" />
          <stop offset="1" stopColor="#388E3C" />
        </linearGradient>
      </defs>
    </svg>
  );
}

export default LeafLogo;