import { SVGProps } from 'react';

interface PlantLogoProps extends SVGProps<SVGSVGElement> {
  variant?: 'default' | 'small' | 'large';
}

export function PlantLogo({ 
  variant = 'default', 
  className = '', 
  ...props 
}: PlantLogoProps) {
  // Define sizes based on variant
  const sizes = {
    small: { width: 24, height: 24 },
    default: { width: 32, height: 32 },
    large: { width: 48, height: 48 },
  };
  
  const { width, height } = sizes[variant];
  
  return (
    <svg
      width={width}
      height={height}
      viewBox="0 0 512 512"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
      {...props}
    >
      {/* Plant Stem */}
      <path d="M256 300V190" stroke="#8BC34A" strokeWidth="12" strokeLinecap="round" />
      
      {/* Middle Leaf */}
      <path d="M256 60C256 60 256 140 256 190C276 170 320 120 256 60Z" fill="#A4E054" />
      <path d="M256 60C256 60 256 140 256 190C236 170 192 120 256 60Z" fill="#8BC34A" />
      
      {/* Left Leaf */}
      <path d="M180 120C180 120 230 140 256 190C220 190 150 180 180 120Z" fill="#A4E054" />
      <path d="M180 120C180 120 210 160 256 190C220 170 160 160 180 120Z" fill="#8BC34A" />
      
      {/* Right Leaf */}
      <path d="M332 120C332 120 282 140 256 190C292 190 362 180 332 120Z" fill="#A4E054" />
      <path d="M332 120C332 120 302 160 256 190C292 170 352 160 332 120Z" fill="#8BC34A" />
      
      {/* Soil */}
      <path d="M350 380C350 380 320 320 256 320C192 320 162 380 162 380L350 380Z" fill="#A67C52" />
      <path d="M162 380C162 380 200 340 256 340C312 340 350 380 350 380L162 380Z" fill="#D4A276" />
      
      {/* Hand */}
      <path d="M140 420C120 420 100 400 100 380L100 350C100 340 110 330 120 330L160 330C170 330 180 340 180 350L180 380C180 400 160 420 140 420Z" fill="#FFCCBC" />
      <path d="M100 380L100 350C100 340 110 330 120 330L160 330C170 330 180 340 180 350L180 380" stroke="#FFCCBC" strokeWidth="5" />
      <path d="M380 420L350 380L180 380C180 380 220 420 256 420L380 420Z" fill="#FFCCBC" />
      <path d="M100 350L100 380L140 380L180 350" fill="#E57373" />
    </svg>
  );
}

export default PlantLogo;