import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Badge } from "@/components/ui/badge";
import { 
  Card, 
  CardContent, 
  CardHeader, 
  CardTitle, 
  CardDescription 
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { TruckIcon, CropIcon, PlusIcon } from "@/lib/icons";
import { useLanguage } from "@/context/language-context";
import { Skeleton } from "@/components/ui/skeleton";

interface Transporter {
  id: number;
  name: string;
  capacity: number;
  ratePerKm: number;
  location: string;
  available: boolean;
  contact: string;
}

interface TransportPool {
  id: number;
  destination: string;
  departureDate: string;
  cropType: string;
  capacity: number;
  filledCapacity: number;
  savingsPercentage: number;
}

export default function TransportOptions() {
  const { t } = useLanguage();
  const [activeTab, setActiveTab] = useState("transporters");
  
  // Get transporters data
  const { data: transporters, isLoading: isTransportersLoading } = useQuery({
    queryKey: ['/api/transporters'],
    queryFn: async () => {
      const response = await fetch('/api/transporters');
      if (!response.ok) return [];
      return await response.json();
    }
  });
  
  // Get transport pools data
  const { data: transportPools, isLoading: isPoolsLoading } = useQuery({
    queryKey: ['/api/transport-pools'],
    queryFn: async () => {
      const response = await fetch('/api/transport-pools');
      if (!response.ok) return [];
      return await response.json();
    }
  });

  return (
    <Card className="shadow-sm border-0">
      <CardHeader className="pb-2">
        <div className="flex justify-between items-center">
          <div>
            <CardTitle className="text-lg font-bold">{t("transportOptions")}</CardTitle>
            <CardDescription>{t("transportOptionsDescription")}</CardDescription>
          </div>
        </div>
      </CardHeader>
      <CardContent>
        <Tabs defaultValue="transporters" className="w-full" onValueChange={setActiveTab}>
          <TabsList className="grid grid-cols-2 mb-4">
            <TabsTrigger value="transporters" className="flex items-center justify-center">
              <TruckIcon className="h-4 w-4 mr-2" />
              {t("transporters")}
            </TabsTrigger>
            <TabsTrigger value="pools" className="flex items-center justify-center">
              <CropIcon className="h-4 w-4 mr-2" />
              {t("transportPools")}
            </TabsTrigger>
          </TabsList>
          
          <TabsContent value="transporters">
            {isTransportersLoading ? (
              <TransportersSkeleton />
            ) : (
              <div className="space-y-3">
                {transporters?.map((transporter: Transporter) => (
                  <div 
                    key={transporter.id}
                    className="border border-neutral-light rounded-lg p-3 hover:border-primary cursor-pointer transition-colors"
                  >
                    <div className="flex justify-between items-start">
                      <div>
                        <h3 className="font-semibold">{transporter.name}</h3>
                        <p className="text-sm text-neutral-medium">{transporter.location}</p>
                      </div>
                      <Badge variant={transporter.available ? "default" : "outline"}>
                        {transporter.available ? t("available") : t("unavailable")}
                      </Badge>
                    </div>
                    <div className="mt-2 flex flex-wrap gap-2 text-sm">
                      <span className="bg-neutral-lightest px-2 py-1 rounded">
                        {t("capacity")}: {transporter.capacity} {t("tonnes")}
                      </span>
                      <span className="bg-neutral-lightest px-2 py-1 rounded">
                        ₹{transporter.ratePerKm}/km
                      </span>
                    </div>
                    <div className="mt-3 flex justify-between items-center">
                      <span className="text-sm text-neutral-medium">{t("contact")}: {transporter.contact}</span>
                      <Button size="sm" variant="outline">{t("contact")}</Button>
                    </div>
                  </div>
                ))}
                <Button variant="outline" className="w-full mt-4">
                  <PlusIcon className="h-4 w-4 mr-2" />
                  {t("findMoreTransporters")}
                </Button>
              </div>
            )}
          </TabsContent>
          
          <TabsContent value="pools">
            {isPoolsLoading ? (
              <PoolsSkeleton />
            ) : (
              <div className="space-y-3">
                {transportPools?.map((pool: TransportPool) => (
                  <div 
                    key={pool.id}
                    className="border border-neutral-light rounded-lg p-3 hover:border-primary cursor-pointer transition-colors"
                  >
                    <div className="flex justify-between items-start mb-2">
                      <div>
                        <h3 className="font-semibold">{t("poolTo")} {pool.destination}</h3>
                        <p className="text-sm text-neutral-medium">
                          {new Date(pool.departureDate).toLocaleDateString('en-IN', { 
                            day: 'numeric', 
                            month: 'short',
                            year: 'numeric'
                          })}
                        </p>
                      </div>
                      <Badge variant="secondary" className="bg-success-light text-success border-success">
                        {pool.savingsPercentage}% {t("savings")}
                      </Badge>
                    </div>
                    <div className="mt-2">
                      <div className="flex justify-between mb-1 text-sm">
                        <span>{t("cropType")}: <strong>{pool.cropType}</strong></span>
                        <span>
                          {pool.filledCapacity}/{pool.capacity} {t("tonnes")}
                        </span>
                      </div>
                      <div className="w-full bg-neutral-light rounded-full h-2">
                        <div 
                          className="bg-primary h-2 rounded-full" 
                          style={{ width: `${(pool.filledCapacity / pool.capacity) * 100}%` }}
                        ></div>
                      </div>
                    </div>
                    <div className="mt-3 flex justify-end">
                      <Button size="sm">{t("joinPool")}</Button>
                    </div>
                  </div>
                ))}
                <Button variant="outline" className="w-full mt-4">
                  <PlusIcon className="h-4 w-4 mr-2" />
                  {t("createNewPool")}
                </Button>
              </div>
            )}
          </TabsContent>
        </Tabs>
      </CardContent>
    </Card>
  );
}

function TransportersSkeleton() {
  return (
    <div className="space-y-3">
      {[1, 2, 3].map(i => (
        <div key={i} className="border border-neutral-light rounded-lg p-3">
          <div className="flex justify-between items-start">
            <div>
              <Skeleton className="h-5 w-32 mb-2" />
              <Skeleton className="h-4 w-20" />
            </div>
            <Skeleton className="h-6 w-20 rounded-full" />
          </div>
          <div className="mt-2 flex gap-2">
            <Skeleton className="h-7 w-24 rounded" />
            <Skeleton className="h-7 w-20 rounded" />
          </div>
          <div className="mt-3 flex justify-between items-center">
            <Skeleton className="h-4 w-28" />
            <Skeleton className="h-9 w-20 rounded" />
          </div>
        </div>
      ))}
    </div>
  );
}

function PoolsSkeleton() {
  return (
    <div className="space-y-3">
      {[1, 2, 3].map(i => (
        <div key={i} className="border border-neutral-light rounded-lg p-3">
          <div className="flex justify-between items-start mb-2">
            <div>
              <Skeleton className="h-5 w-32 mb-2" />
              <Skeleton className="h-4 w-28" />
            </div>
            <Skeleton className="h-6 w-20 rounded-full" />
          </div>
          <div className="mt-2">
            <div className="flex justify-between mb-1">
              <Skeleton className="h-4 w-24" />
              <Skeleton className="h-4 w-20" />
            </div>
            <Skeleton className="h-2 w-full rounded-full" />
          </div>
          <div className="mt-3 flex justify-end">
            <Skeleton className="h-9 w-20 rounded" />
          </div>
        </div>
      ))}
    </div>
  );
}