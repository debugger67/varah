import { useQuery } from "@tanstack/react-query";
import { useLanguage } from "@/context/language-context";
import { Skeleton } from "@/components/ui/skeleton";

export default function MarketSuggestions() {
  const { t } = useLanguage();
  
  // Query for user's crops
  const { data: crops, isLoading: cropsLoading } = useQuery({
    queryKey: ['/api/crops'],
  });
  
  // Assume we have the first crop of the user
  const userCrop = crops?.[0];

  // Get crop market prices for comparison
  const { data: cropMarkets, isLoading: marketsLoading } = useQuery({
    queryKey: ['/api/crop-markets', { cropName: userCrop?.name }],
    enabled: !!userCrop?.name
  });

  const isLoading = cropsLoading || marketsLoading || !userCrop;

  return (
    <div className="mb-6">
      <h3 className="text-lg font-heading font-semibold mb-3">{t("suggestedForCrops")}</h3>
      <div className="bg-neutral-lightest border border-neutral-light rounded-lg p-4">
        {isLoading ? (
          <>
            <div className="flex flex-col md:flex-row md:items-center md:justify-between mb-4">
              <div className="mb-3 md:mb-0">
                <Skeleton className="h-12 w-64" />
              </div>
              <Skeleton className="h-10 w-48" />
            </div>
            <div className="border-t border-neutral-light pt-4">
              <Skeleton className="h-6 w-48 mb-4" />
              <Skeleton className="h-32 w-full" />
            </div>
          </>
        ) : (
          <>
            <div className="flex flex-col md:flex-row md:items-center md:justify-between mb-4">
              <div className="mb-3 md:mb-0">
                <div className="flex items-center">
                  <img 
                    src={userCrop?.name === "Wheat" 
                      ? "https://images.unsplash.com/photo-1581515286348-98549702050f" 
                      : "https://images.unsplash.com/photo-1586201375761-83865001e8c7"} 
                    className="w-12 h-12 rounded-lg mr-3 object-cover" 
                    alt={userCrop?.name || "Crop"} 
                  />
                  <div>
                    <h4 className="font-heading font-bold">{t("your")} {userCrop?.name} {t("crop")}</h4>
                    <p className="text-sm text-neutral-medium">{t("readyForHarvest")}</p>
                  </div>
                </div>
              </div>
              <div className="flex space-x-2">
                <button className="bg-primary text-white rounded-lg px-3 py-1.5 text-sm font-semibold">{t("transportOptions")}</button>
                <button className="bg-secondary text-white rounded-lg px-3 py-1.5 text-sm font-semibold">{t("findBuyers")}</button>
              </div>
            </div>
            
            <div className="border-t border-neutral-light pt-4">
              <h5 className="font-heading font-semibold mb-2">{t("priceComparison")}</h5>
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead>
                    <tr className="text-left text-neutral-medium">
                      <th className="pb-2">{t("market")}</th>
                      <th className="pb-2">{t("distance")}</th>
                      <th className="pb-2">{t("price")}</th>
                      <th className="pb-2">{t("demand")}</th>
                      <th className="pb-2">{t("transportCost")}</th>
                      <th className="pb-2">{t("netProfit")}</th>
                      <th className="pb-2"></th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr className="border-b border-neutral-light">
                      <td className="py-2 font-semibold">Delhi Mandi</td>
                      <td>450 km</td>
                      <td className="font-semibold">₹2,240</td>
                      <td>
                        <span className="inline-block bg-green-100 text-green-800 text-xs px-2 py-0.5 rounded-full">{t("high")}</span>
                      </td>
                      <td>₹250/q</td>
                      <td className="font-semibold text-green-600">₹1,990/q</td>
                      <td>
                        <button className="text-primary font-semibold text-xs">{t("details")}</button>
                      </td>
                    </tr>
                    <tr className="border-b border-neutral-light bg-primary bg-opacity-5">
                      <td className="py-2 font-semibold">Indore Mandi</td>
                      <td>220 km</td>
                      <td className="font-semibold">₹2,050</td>
                      <td>
                        <span className="inline-block bg-green-100 text-green-800 text-xs px-2 py-0.5 rounded-full">{t("high")}</span>
                      </td>
                      <td>₹120/q</td>
                      <td className="font-semibold text-green-600">₹1,930/q</td>
                      <td>
                        <button className="bg-primary text-white rounded px-2 py-0.5 text-xs">{t("bestMatch")}</button>
                      </td>
                    </tr>
                    <tr>
                      <td className="py-2 font-semibold">Local APMC</td>
                      <td>15 km</td>
                      <td className="font-semibold">₹1,850</td>
                      <td>
                        <span className="inline-block bg-yellow-100 text-yellow-800 text-xs px-2 py-0.5 rounded-full">{t("medium")}</span>
                      </td>
                      <td>₹20/q</td>
                      <td className="font-semibold text-green-600">₹1,830/q</td>
                      <td>
                        <button className="text-primary font-semibold text-xs">{t("details")}</button>
                      </td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>
          </>
        )}
      </div>
    </div>
  );
}
