import { useQuery } from "@tanstack/react-query";
import { useLanguage } from "@/context/language-context";
import { PlusIcon } from "@/lib/icons";
import TrendingMarkets from "./trending-markets";
import MarketSuggestions from "./market-suggestions";
import TransportOptions from "./transport-options";

export default function MarketSection() {
  const { t } = useLanguage();
  
  const { data: marketsData, isLoading: marketsLoading } = useQuery({
    queryKey: ['/api/markets'],
  });

  return (
    <section className="bg-white rounded-xl shadow-sm p-4 mb-6">
      {/* Section Header */}
      <div className="flex justify-between items-center mb-4">
        <h2 className="text-xl font-heading font-bold flex items-center">
          <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 mr-2 text-primary" viewBox="0 0 20 20" fill="currentColor">
            <path d="M9 6a3 3 0 11-6 0 3 3 0 016 0zM17 6a3 3 0 11-6 0 3 3 0 016 0zM12.93 17c.046-.327.07-.66.07-1a6.97 6.97 0 00-1.5-4.33A5 5 0 0119 16v1h-6.07zM6 11a5 5 0 015 5v1H1v-1a5 5 0 015-5z" />
          </svg>
          {t("marketplace")}
        </h2>
        <div className="flex space-x-3">
          <select className="border border-neutral-light rounded-lg px-3 py-2 bg-white text-neutral-dark">
            <option>{t("allMarkets")}</option>
            <option>{t("localDistrict")}</option>
            <option>{t("state")}</option>
            <option>{t("national")}</option>
            <option>{t("international")}</option>
          </select>
          <button className="bg-primary text-white rounded-lg px-4 py-2 font-semibold flex items-center">
            <PlusIcon className="h-5 w-5 mr-1" />
            {t("listCrop")}
          </button>
        </div>
      </div>

      {/* Trending Markets */}
      <TrendingMarkets markets={marketsData} isLoading={marketsLoading} />

      {/* Market Suggestions */}
      <MarketSuggestions />

      {/* Transport Options */}
      <TransportOptions />
    </section>
  );
}
