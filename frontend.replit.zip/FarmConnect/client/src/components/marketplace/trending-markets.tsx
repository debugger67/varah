import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Badge } from "@/components/ui/badge";
import { ArrowUpIcon, ArrowDownIcon } from "@/lib/icons";
import { useLanguage } from "@/context/language-context";
import { Skeleton } from "@/components/ui/skeleton";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";

interface CropMarket {
  id: number;
  marketId: number;
  cropName: string;
  price: number;
  priceChange: number;
  availability: string;
  demandLevel: string;
}

interface Market {
  id: number;
  name: string;
  location: string;
  state: string;
  district: string;
  type: string;
  demandLevel: string;
}

interface TrendingMarketsProps {
  markets?: Market[];
  isLoading?: boolean;
}

export default function TrendingMarkets({ markets, isLoading = false }: TrendingMarketsProps) {
  const { t } = useLanguage();
  const [selectedMarketType, setSelectedMarketType] = useState<string>("all");
  
  // Get crop markets data
  const { data: cropMarkets, isLoading: isCropMarketsLoading } = useQuery({
    queryKey: ['/api/crop-markets'],
    queryFn: async () => {
      // This would normally query by marketId, but for demo we'll just get all
      const response = await fetch('/api/crop-markets?dummy=1');
      if (!response.ok) return [];
      return response.json();
    },
    enabled: !!markets
  });

  // Loading state
  if (isLoading || !markets) {
    return <TrendingMarketsSkeleton />;
  }

  // Filter markets by type if needed
  const filteredMarkets = selectedMarketType === "all" 
    ? markets 
    : markets.filter(market => market.type === selectedMarketType);

  // Market type tabs
  const marketTypes = ["all", "local", "district", "state", "national"];

  return (
    <Card className="shadow-sm bg-white border-0">
      <CardHeader className="pb-2">
        <div className="flex justify-between items-center">
          <CardTitle className="text-lg font-bold">{t("trendingMarkets")}</CardTitle>
          <div className="flex space-x-1 text-xs">
            {marketTypes.map(type => (
              <button
                key={type}
                onClick={() => setSelectedMarketType(type)}
                className={`px-3 py-1 rounded-full capitalize ${
                  selectedMarketType === type
                    ? 'bg-primary text-white'
                    : 'bg-neutral-lightest text-neutral-medium hover:bg-neutral-light'
                }`}
              >
                {t(type === "all" ? "all" : type)}
              </button>
            ))}
          </div>
        </div>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {filteredMarkets.slice(0, 5).map(market => (
            <div 
              key={market.id}
              className="border border-neutral-light rounded-lg p-3 hover:border-primary cursor-pointer transition-colors"
            >
              <div className="flex justify-between items-start mb-2">
                <div>
                  <h3 className="font-semibold">{market.name}</h3>
                  <p className="text-sm text-neutral-medium">{market.location}, {market.state}</p>
                </div>
                <Badge variant={getDemandBadgeVariant(market.demandLevel)}>
                  {t(market.demandLevel.toLowerCase())}
                </Badge>
              </div>
              
              {/* Market Crops */}
              {!isCropMarketsLoading && cropMarkets && (
                <div className="mt-3 space-y-2">
                  {getMarketCrops(market, cropMarkets).map(cropMarket => (
                    <div key={cropMarket.id} className="flex justify-between items-center text-sm">
                      <span className="font-medium">{cropMarket.cropName}</span>
                      <div className="flex items-center">
                        <span className="font-semibold">₹{cropMarket.price.toLocaleString('en-IN')}/q</span>
                        {cropMarket.priceChange !== 0 && (
                          <div className={`flex items-center ml-2 ${
                            cropMarket.priceChange > 0 ? 'text-success' : 'text-destructive'
                          }`}>
                            {cropMarket.priceChange > 0 ? (
                              <ArrowUpIcon className="h-3 w-3 mr-1" />
                            ) : (
                              <ArrowDownIcon className="h-3 w-3 mr-1" />
                            )}
                            <span className="text-xs">{Math.abs(cropMarket.priceChange)}%</span>
                          </div>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}

// Helper functions
function getDemandBadgeVariant(demandLevel: string): "default" | "secondary" | "destructive" | "outline" {
  switch (demandLevel.toLowerCase()) {
    case "high":
      return "default";
    case "medium":
      return "secondary";
    default:
      return "outline";
  }
}

function getMarketCrops(market: Market, cropMarkets: CropMarket[]) {
  const marketCrops = cropMarkets.filter(cm => cm.marketId === market.id);
  return marketCrops.slice(0, 3); // Show only top 3 crops per market
}

function TrendingMarketsSkeleton() {
  return (
    <Card className="shadow-sm border-0">
      <CardHeader className="pb-2">
        <div className="flex justify-between items-center">
          <Skeleton className="h-6 w-40" />
          <div className="flex space-x-1">
            <Skeleton className="h-7 w-16" />
            <Skeleton className="h-7 w-16" />
            <Skeleton className="h-7 w-16" />
          </div>
        </div>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {[1, 2, 3].map(i => (
            <div key={i} className="border border-neutral-light rounded-lg p-3">
              <div className="flex justify-between items-start mb-2">
                <div>
                  <Skeleton className="h-5 w-32 mb-2" />
                  <Skeleton className="h-4 w-48" />
                </div>
                <Skeleton className="h-6 w-16 rounded-full" />
              </div>
              <div className="mt-3 space-y-2">
                {[1, 2, 3].map(j => (
                  <div key={j} className="flex justify-between items-center">
                    <Skeleton className="h-4 w-24" />
                    <Skeleton className="h-4 w-20" />
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}