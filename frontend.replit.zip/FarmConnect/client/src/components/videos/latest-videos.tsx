import { useQuery } from "@tanstack/react-query";
import { useLanguage } from "@/context/language-context";
import { VideosIcon, VideoPlayIcon } from "@/lib/icons";
import { Skeleton } from "@/components/ui/skeleton";

export default function LatestVideos() {
  const { t } = useLanguage();
  
  const { data: videos, isLoading } = useQuery({
    queryKey: ['/api/videos'],
  });

  return (
    <section className="bg-white rounded-xl shadow-sm p-4 mb-6">
      <div className="flex justify-between items-center mb-4">
        <h2 className="text-xl font-heading font-bold flex items-center">
          <VideosIcon className="h-6 w-6 mr-2 text-primary" />
          {t("latestVideos")}
        </h2>
        <a href="#" className="text-primary font-semibold">{t("viewAll")}</a>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {isLoading ? (
          // Loading skeletons
          Array(3).fill(0).map((_, i) => (
            <div key={i} className="bg-neutral-lightest rounded-lg overflow-hidden border border-neutral-light">
              <Skeleton className="w-full h-48" />
              <div className="p-3">
                <div className="flex items-start space-x-2 mb-2">
                  <Skeleton className="h-8 w-8 rounded-full" />
                  <div className="flex-1">
                    <Skeleton className="h-5 w-full mb-1" />
                    <Skeleton className="h-4 w-40" />
                  </div>
                </div>
                <div className="flex justify-between">
                  <Skeleton className="h-4 w-20" />
                  <Skeleton className="h-4 w-20" />
                </div>
              </div>
            </div>
          ))
        ) : (
          videos?.map((video: any) => (
            <div key={video.id} className="bg-neutral-lightest rounded-lg overflow-hidden border border-neutral-light">
              <div className="relative">
                <img 
                  src={video.thumbnailUrl} 
                  className="w-full h-48 object-cover" 
                  alt={video.title} 
                />
                <div className="absolute inset-0 flex items-center justify-center">
                  <button className="bg-primary bg-opacity-80 rounded-full p-3">
                    <VideoPlayIcon className="h-8 w-8 text-white" />
                  </button>
                </div>
                <div className="absolute bottom-0 right-0 bg-primary text-white text-xs px-2 py-1 m-2 rounded">
                  {video.duration}
                </div>
              </div>
              <div className="p-3">
                <div className="flex items-start space-x-2 mb-2">
                  <img 
                    src="https://images.unsplash.com/photo-1550345332-09e3ac987658" 
                    className="w-8 h-8 rounded-full object-cover" 
                    alt={video.authorName} 
                  />
                  <div>
                    <h4 className="font-heading font-bold">{video.title}</h4>
                    <p className="text-xs text-neutral-medium">{video.authorName} • {video.authorRole}</p>
                  </div>
                </div>
                <div className="flex justify-between text-xs text-neutral-medium">
                  <span>{video.views}K {t("views")}</span>
                  <span>
                    {Math.floor((new Date().getTime() - new Date(video.uploadedAt).getTime()) / (1000 * 60 * 60 * 24))} {t("daysAgo")}
                  </span>
                </div>
              </div>
            </div>
          ))
        )}
      </div>
    </section>
  );
}
