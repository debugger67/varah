import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { 
  Card, 
  CardContent, 
  CardHeader, 
  CardTitle,
  CardDescription 
} from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { useLanguage } from "@/context/language-context";
import { useWeather } from "@/hooks/use-weather";
import { NotificationIcon, WeatherIcon, CropIcon, MoneyIcon } from "@/lib/icons";

interface Notification {
  id: number;
  userId: number;
  type: string;
  title: string;
  message: string;
  isRead: boolean;
  timestamp: string;
  relatedId?: number;
  actionUrl?: string;
}

export default function NotificationList() {
  const { t } = useLanguage();
  const [filter, setFilter] = useState<string>("all");
  const { weatherData } = useWeather("Amravati, Maharashtra");
  
  // In a real app, we'd get userId from auth context
  const userId = 1;
  
  // Simulate notification data
  const { data: notifications, isLoading } = useQuery({
    queryKey: ['/api/notifications', userId],
    queryFn: async () => {
      // This would be a real API call in production
      return [
        {
          id: 1,
          userId: 1,
          type: "weather",
          title: "Heavy Rain Warning",
          message: "Heavy rainfall expected in your area in the next 24 hours. Take necessary precautions for your crops.",
          isRead: false,
          timestamp: "2025-03-18T08:30:00",
          actionUrl: "/weather-alerts"
        },
        {
          id: 2,
          userId: 1,
          type: "crop",
          title: "Pest Alert for Wheat",
          message: "Increased risk of aphid infestation detected in your wheat crop. Consider applying appropriate pesticides.",
          isRead: true,
          timestamp: "2025-03-17T14:15:00",
          relatedId: 1,
          actionUrl: "/farm"
        },
        {
          id: 3,
          userId: 1,
          type: "market",
          title: "Price Increase Alert",
          message: "Wheat prices have increased by 8% in Nagpur Mandi. Consider selling your harvest now for better returns.",
          isRead: false,
          timestamp: "2025-03-17T09:45:00",
          actionUrl: "/marketplace"
        },
        {
          id: 4,
          userId: 1,
          type: "financial",
          title: "Subsidy Credit",
          message: "Government fertilizer subsidy of ₹5,000 has been credited to your account.",
          isRead: true,
          timestamp: "2025-03-16T11:20:00",
          actionUrl: "/finances"
        },
        {
          id: 5,
          userId: 1,
          type: "weather",
          title: "Temperature Drop Alert",
          message: "Temperature expected to drop below 10°C tonight. Cover sensitive crops to prevent frost damage.",
          isRead: false,
          timestamp: "2025-03-15T16:30:00",
          actionUrl: "/weather-alerts"
        }
      ];
    }
  });

  // Filter notifications based on selected type
  const filteredNotifications = notifications 
    ? filter === "all" 
      ? notifications 
      : notifications.filter(notification => notification.type === filter)
    : [];
  
  // Calculate unread count
  const unreadCount = notifications?.filter(n => !n.isRead).length || 0;

  // Define notification types for filter
  const notificationTypes = [
    { id: "all", label: "all" },
    { id: "weather", label: "weather" },
    { id: "crop", label: "crop" },
    { id: "market", label: "market" },
    { id: "financial", label: "financial" }
  ];

  // Function to render the appropriate icon based on notification type
  const getNotificationIcon = (type: string) => {
    switch (type) {
      case "weather":
        return <WeatherIcon className="h-5 w-5 text-blue-500" />;
      case "crop":
        return <CropIcon className="h-5 w-5 text-green-500" />;
      case "market":
        return <NotificationIcon className="h-5 w-5 text-orange-500" />;
      case "financial":
        return <MoneyIcon className="h-5 w-5 text-purple-500" />;
      default:
        return <NotificationIcon className="h-5 w-5 text-neutral-500" />;
    }
  };

  // Function to render notification color based on type
  const getNotificationColor = (type: string) => {
    switch (type) {
      case "weather":
        return "bg-blue-50";
      case "crop":
        return "bg-green-50";
      case "market":
        return "bg-orange-50";
      case "financial":
        return "bg-purple-50";
      default:
        return "bg-neutral-50";
    }
  };

  // Function to format date
  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    const now = new Date();
    const diffMs = now.getTime() - date.getTime();
    const diffMins = Math.floor(diffMs / 60000);
    const diffHours = Math.floor(diffMins / 60);
    const diffDays = Math.floor(diffHours / 24);
    
    if (diffMins < 60) {
      return `${diffMins} ${t("minutesAgo")}`;
    } else if (diffHours < 24) {
      return `${diffHours} ${t("hoursAgo")}`;
    } else {
      return `${diffDays} ${t("daysAgo")}`;
    }
  };

  return (
    <Card className="shadow-sm border-0">
      <CardHeader className="pb-2">
        <div className="flex justify-between items-center">
          <div>
            <CardTitle className="text-lg font-bold flex items-center">
              {t("notifications")}
              {unreadCount > 0 && (
                <Badge className="ml-2 bg-primary">{unreadCount}</Badge>
              )}
            </CardTitle>
            <CardDescription>{t("notificationsDescription")}</CardDescription>
          </div>
          
          {/* Mark all as read button */}
          {unreadCount > 0 && (
            <Button variant="ghost" size="sm">
              {t("markAllAsRead")}
            </Button>
          )}
        </div>
      </CardHeader>
      <CardContent>
        {/* Notification filters */}
        <div className="flex space-x-2 mb-4 overflow-x-auto pb-1">
          {notificationTypes.map(type => (
            <button
              key={type.id}
              onClick={() => setFilter(type.id)}
              className={`px-3 py-1.5 rounded-lg flex items-center text-sm whitespace-nowrap ${
                filter === type.id
                  ? 'bg-primary text-white'
                  : 'bg-neutral-lightest text-neutral-dark hover:bg-neutral-light'
              }`}
            >
              <span className="font-medium capitalize">{t(type.label)}</span>
              {type.id === "all" && unreadCount > 0 && (
                <Badge variant="outline" className="ml-2 bg-white bg-opacity-20 text-white border-white">
                  {unreadCount}
                </Badge>
              )}
            </button>
          ))}
        </div>
        
        {/* Notifications list */}
        {isLoading ? (
          <NotificationSkeleton />
        ) : (
          <div className="space-y-3">
            {filteredNotifications.length === 0 ? (
              <div className="text-center py-8">
                <NotificationIcon className="w-12 h-12 text-neutral-300 mx-auto mb-3" />
                <p className="text-neutral-500">{t("noNotifications")}</p>
              </div>
            ) : (
              filteredNotifications.map(notification => (
                <div 
                  key={notification.id}
                  className={`p-3 rounded-lg border ${notification.isRead ? 'border-neutral-light' : 'border-primary'} hover:border-primary cursor-pointer transition-colors flex`}
                >
                  <div className={`w-10 h-10 rounded-full ${getNotificationColor(notification.type)} flex items-center justify-center mr-3 flex-shrink-0`}>
                    {getNotificationIcon(notification.type)}
                  </div>
                  <div className="flex-grow">
                    <div className="flex justify-between items-start">
                      <h3 className={`font-medium ${!notification.isRead ? 'text-primary' : ''}`}>
                        {notification.title}
                      </h3>
                      <span className="text-xs text-neutral-medium ml-2">
                        {formatDate(notification.timestamp)}
                      </span>
                    </div>
                    <p className="text-sm text-neutral-medium mt-1">
                      {notification.message}
                    </p>
                    <div className="mt-2 flex justify-end">
                      <Button variant="link" size="sm" className="h-auto p-0 text-xs">
                        {t("viewDetails")}
                      </Button>
                    </div>
                  </div>
                  {!notification.isRead && (
                    <div className="w-2 h-2 bg-primary rounded-full mt-2 flex-shrink-0" />
                  )}
                </div>
              ))
            )}
          </div>
        )}
      </CardContent>
    </Card>
  );
}

// Skeleton loading state
function NotificationSkeleton() {
  return (
    <div className="space-y-3">
      {[1, 2, 3, 4].map(i => (
        <div key={i} className="p-3 rounded-lg border border-neutral-light flex">
          <Skeleton className="w-10 h-10 rounded-full mr-3 flex-shrink-0" />
          <div className="flex-grow">
            <div className="flex justify-between items-start">
              <Skeleton className="h-5 w-32" />
              <Skeleton className="h-3 w-16 ml-2" />
            </div>
            <Skeleton className="h-4 w-full mt-2" />
            <Skeleton className="h-4 w-3/4 mt-1" />
            <div className="mt-2 flex justify-end">
              <Skeleton className="h-4 w-20" />
            </div>
          </div>
        </div>
      ))}
    </div>
  );
}