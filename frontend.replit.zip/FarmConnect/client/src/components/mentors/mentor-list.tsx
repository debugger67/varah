import { useQuery } from "@tanstack/react-query";
import { useLanguage } from "@/context/language-context";
import { Skeleton } from "@/components/ui/skeleton";

export default function MentorList() {
  const { t } = useLanguage();
  
  const { data: mentors, isLoading } = useQuery({
    queryKey: ['/api/mentors'],
  });

  return (
    <div className="divide-y divide-neutral-light">
      {isLoading ? (
        // Loading skeletons
        Array(3).fill(0).map((_, i) => (
          <div key={i} className="py-3 first:pt-0 last:pb-0">
            <div className="flex items-start space-x-3">
              <Skeleton className="w-10 h-10 rounded-full" />
              <div className="flex-1">
                <Skeleton className="h-5 w-40 mb-1" />
                <Skeleton className="h-4 w-56 mb-2" />
                <div className="flex space-x-2">
                  <Skeleton className="h-8 w-20" />
                  <Skeleton className="h-8 w-20" />
                </div>
              </div>
            </div>
          </div>
        ))
      ) : (
        mentors?.map((mentor: any) => (
          <div key={mentor.id} className="py-3 first:pt-0 last:pb-0">
            <div className="flex items-start space-x-3">
              <img 
                src={mentor.profileImage} 
                alt={mentor.name} 
                className="w-10 h-10 rounded-full object-cover" 
              />
              <div>
                <div className="flex items-center">
                  <h4 className="font-heading font-semibold">{mentor.name}</h4>
                  {mentor.isOnline && (
                    <span className="ml-2 bg-green-100 text-green-800 text-xs px-2 py-0.5 rounded-full">
                      {t("online")}
                    </span>
                  )}
                </div>
                <p className="text-xs text-neutral-medium">{mentor.specialization}, {mentor.organization}</p>
                <div className="flex mt-1 space-x-2">
                  <button className="bg-primary text-white text-xs rounded px-2 py-1">
                    {t("connect")}
                  </button>
                  <button className="border border-neutral-medium text-neutral-dark text-xs rounded px-2 py-1">
                    {t("message")}
                  </button>
                </div>
              </div>
            </div>
          </div>
        ))
      )}
    </div>
  );
}
