import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { 
  Card, 
  CardContent, 
  CardHeader, 
  CardTitle,
  CardDescription 
} from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { ArrowUpIcon, ArrowDownIcon, MoneyIcon, PlusIcon } from "@/lib/icons";
import { useLanguage } from "@/context/language-context";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Skeleton } from "@/components/ui/skeleton";

interface FinancialTransaction {
  id: number;
  userId: number;
  date: string;
  transactionType: string;
  category: string;
  amount: number;
  description: string;
}

export default function FinancialSummary() {
  const { t } = useLanguage();
  const [selectedPeriod, setSelectedPeriod] = useState<string>("month");
  
  // In a real app, we'd get userId from auth context
  const userId = 1;
  
  // Get financial data
  const { data: transactions, isLoading } = useQuery({
    queryKey: ['/api/financial-transactions', userId],
    queryFn: async () => {
      // This would be `/api/financial-transactions?userId=${userId}` in a real app
      // But since our dummy data requires userId, we'll just return mock for now
      return [
        {
          id: 1,
          userId: 1,
          date: "2025-02-15",
          transactionType: "income",
          category: "crop_sale",
          amount: 45000,
          description: "Wheat sale to Nagpur Mandi"
        },
        {
          id: 2,
          userId: 1,
          date: "2025-02-10",
          transactionType: "expense",
          category: "fertilizer",
          amount: 8500,
          description: "NPK and micronutrients purchase"
        },
        {
          id: 3,
          userId: 1,
          date: "2025-02-05",
          transactionType: "expense",
          category: "pesticide",
          amount: 3200,
          description: "Insecticide purchase"
        },
        {
          id: 4,
          userId: 1,
          date: "2025-01-20",
          transactionType: "income",
          category: "subsidy",
          amount: 5000,
          description: "Government fertilizer subsidy"
        },
        {
          id: 5,
          userId: 1,
          date: "2025-01-15",
          transactionType: "expense",
          category: "equipment",
          amount: 12000,
          description: "Water pump repair"
        }
      ];
    }
  });

  // Filter transactions by period
  const filteredTransactions = transactions ? filterTransactionsByPeriod(transactions, selectedPeriod) : [];
  
  // Calculate financial summary
  const summary = calculateFinancialSummary(filteredTransactions);

  return (
    <Card className="shadow-sm border-0">
      <CardHeader className="pb-2">
        <div className="flex justify-between items-center">
          <div>
            <CardTitle className="text-lg font-bold">{t("financialSummary")}</CardTitle>
            <CardDescription>{t("financialSummaryDescription")}</CardDescription>
          </div>
          <Button size="sm" variant="outline" className="flex items-center gap-1">
            <PlusIcon className="h-4 w-4" />
            {t("addTransaction")}
          </Button>
        </div>
      </CardHeader>
      <CardContent>
        {isLoading ? (
          <FinancialSummarySkeleton />
        ) : (
          <div>
            {/* Period tabs */}
            <div className="flex justify-center mb-6">
              <Tabs defaultValue="month" className="w-full" onValueChange={setSelectedPeriod}>
                <TabsList className="grid grid-cols-3">
                  <TabsTrigger value="month">{t("thisMonth")}</TabsTrigger>
                  <TabsTrigger value="quarter">{t("thisQuarter")}</TabsTrigger>
                  <TabsTrigger value="year">{t("thisYear")}</TabsTrigger>
                </TabsList>
              </Tabs>
            </div>
            
            {/* Overview cards */}
            <div className="grid grid-cols-3 gap-4 mb-6">
              <Card className="p-4 border-0 bg-neutral-lightest">
                <div className="text-sm text-neutral-medium mb-2">{t("totalIncome")}</div>
                <div className="text-xl font-bold text-success">₹{summary.totalIncome.toLocaleString('en-IN')}</div>
              </Card>
              <Card className="p-4 border-0 bg-neutral-lightest">
                <div className="text-sm text-neutral-medium mb-2">{t("totalExpenses")}</div>
                <div className="text-xl font-bold text-destructive">₹{summary.totalExpenses.toLocaleString('en-IN')}</div>
              </Card>
              <Card className="p-4 border-0 bg-neutral-lightest">
                <div className="text-sm text-neutral-medium mb-2">{t("netProfit")}</div>
                <div className={`text-xl font-bold ${summary.netBalance >= 0 ? 'text-success' : 'text-destructive'}`}>
                  ₹{summary.netBalance.toLocaleString('en-IN')}
                </div>
              </Card>
            </div>
            
            {/* Recent transactions */}
            <div>
              <div className="flex justify-between items-center mb-3">
                <h3 className="font-medium">{t("recentTransactions")}</h3>
                <Button variant="link" className="text-xs p-0 h-auto">{t("viewAll")}</Button>
              </div>
              
              <div className="space-y-3">
                {filteredTransactions.slice(0, 4).map(transaction => (
                  <div 
                    key={transaction.id}
                    className="flex justify-between items-center p-3 border border-neutral-light rounded-lg hover:border-primary cursor-pointer transition-colors"
                  >
                    <div className="flex items-center">
                      <div className={`w-10 h-10 rounded-full flex items-center justify-center ${
                        transaction.transactionType === 'income' ? 'bg-success bg-opacity-10' : 'bg-destructive bg-opacity-10'
                      }`}>
                        {transaction.transactionType === 'income' 
                          ? <ArrowUpIcon className="h-5 w-5 text-success" /> 
                          : <ArrowDownIcon className="h-5 w-5 text-destructive" />}
                      </div>
                      <div className="ml-3">
                        <p className="font-medium">{t(transaction.category)}</p>
                        <p className="text-sm text-neutral-medium">
                          {new Date(transaction.date).toLocaleDateString('en-IN', { 
                            day: 'numeric', 
                            month: 'short'
                          })}
                        </p>
                      </div>
                    </div>
                    <div className="text-right">
                      <p className={`font-semibold ${
                        transaction.transactionType === 'income' ? 'text-success' : 'text-destructive'
                      }`}>
                        {transaction.transactionType === 'income' ? '+' : '-'}
                        ₹{transaction.amount.toLocaleString('en-IN')}
                      </p>
                      <Badge variant="outline" className="text-xs font-normal">
                        {t(transaction.transactionType)}
                      </Badge>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
}

// Helper functions
function filterTransactionsByPeriod(transactions: FinancialTransaction[], period: string): FinancialTransaction[] {
  const now = new Date();
  let cutoffDate = new Date();
  
  switch (period) {
    case 'month':
      cutoffDate.setMonth(now.getMonth() - 1);
      break;
    case 'quarter':
      cutoffDate.setMonth(now.getMonth() - 3);
      break;
    case 'year':
      cutoffDate.setFullYear(now.getFullYear() - 1);
      break;
    default:
      cutoffDate.setMonth(now.getMonth() - 1);
  }
  
  return transactions.filter(transaction => new Date(transaction.date) >= cutoffDate);
}

function calculateFinancialSummary(transactions: FinancialTransaction[]) {
  let totalIncome = 0;
  let totalExpenses = 0;
  
  transactions.forEach(transaction => {
    if (transaction.transactionType === 'income') {
      totalIncome += transaction.amount;
    } else if (transaction.transactionType === 'expense') {
      totalExpenses += transaction.amount;
    }
  });
  
  const netBalance = totalIncome - totalExpenses;
  
  return {
    totalIncome,
    totalExpenses,
    netBalance
  };
}

function FinancialSummarySkeleton() {
  return (
    <div>
      {/* Period tabs skeleton */}
      <div className="flex justify-center mb-6">
        <Skeleton className="h-10 w-full rounded-lg" />
      </div>
      
      {/* Overview cards skeleton */}
      <div className="grid grid-cols-3 gap-4 mb-6">
        {[1, 2, 3].map(i => (
          <div key={i} className="p-4 bg-neutral-lightest rounded-lg">
            <Skeleton className="h-4 w-24 mb-2" />
            <Skeleton className="h-7 w-20" />
          </div>
        ))}
      </div>
      
      {/* Recent transactions skeleton */}
      <div>
        <div className="flex justify-between items-center mb-3">
          <Skeleton className="h-5 w-40" />
          <Skeleton className="h-4 w-16" />
        </div>
        
        <div className="space-y-3">
          {[1, 2, 3, 4].map(i => (
            <Skeleton key={i} className="h-20 w-full rounded-lg" />
          ))}
        </div>
      </div>
    </div>
  );
}