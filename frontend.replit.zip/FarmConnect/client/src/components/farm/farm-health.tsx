import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { 
  Card, 
  CardContent, 
  CardHeader, 
  CardTitle,
  CardDescription
} from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Button } from "@/components/ui/button";
import { InfoIcon, WeatherIcon } from "@/lib/icons";
import { useLanguage } from "@/context/language-context";
import { useWeather } from "@/hooks/use-weather";

interface Crop {
  id: number;
  name: string;
  status: string;
  farmId: number;
  plantedDate: string;
  harvestDate: string;
  season: string;
  estimatedYield: string;
  currentHealth: number;
  pestRisk: number;
  diseaseRisk: number;
  waterStatus: number;
  nutrientStatus: number;
  notes: string;
}

export default function FarmHealth() {
  const { t } = useLanguage();
  const [selectedCropId, setSelectedCropId] = useState<number | null>(null);
  const { weatherData: weather } = useWeather("Amravati, Maharashtra"); // Default location
  
  // In a real app, we'd get farmId from auth context
  const farmId = 1;
  
  // Get crops data
  const { data: crops, isLoading } = useQuery({
    queryKey: ['/api/crops', farmId],
    queryFn: async () => {
      // This would be `/api/crops?farmId=${farmId}` in a real app
      // But since our dummy data requires farmId, we'll just return mock for now
      return [
        {
          id: 1,
          name: "Wheat",
          status: "growing",
          farmId: 1,
          plantedDate: "2024-11-15",
          harvestDate: "2025-03-25",
          season: "rabi",
          estimatedYield: "45 q/ha",
          currentHealth: 85,
          pestRisk: 20,
          diseaseRisk: 15,
          waterStatus: 75,
          nutrientStatus: 80,
          notes: "Good growth, minor aphid presence"
        },
        {
          id: 2,
          name: "Cotton",
          status: "harvested",
          farmId: 1,
          plantedDate: "2024-06-10",
          harvestDate: "2024-11-05",
          season: "kharif",
          estimatedYield: "22 q/ha",
          currentHealth: 100,
          pestRisk: 0,
          diseaseRisk: 0,
          waterStatus: 100,
          nutrientStatus: 100,
          notes: "Harvested, yield was good"
        },
        {
          id: 3,
          name: "Soybean",
          status: "growing",
          farmId: 1,
          plantedDate: "2024-06-15",
          harvestDate: "2024-10-20",
          season: "kharif",
          estimatedYield: "18 q/ha",
          currentHealth: 65,
          pestRisk: 45,
          diseaseRisk: 30,
          waterStatus: 60,
          nutrientStatus: 70,
          notes: "Showing signs of leaf spot disease, needs fungicide"
        }
      ];
    }
  });

  // Selected crop details
  const selectedCrop = selectedCropId 
    ? crops?.find(crop => crop.id === selectedCropId) 
    : crops?.[0];

  return (
    <Card className="shadow-sm border-0">
      <CardHeader className="pb-2">
        <div className="flex justify-between items-center">
          <div>
            <CardTitle className="text-lg font-bold">{t("farmHealth")}</CardTitle>
            <CardDescription>{t("farmHealthDescription")}</CardDescription>
          </div>
          
          {/* Weather summary */}
          {weather && (
            <div className="flex items-center bg-neutral-lightest px-3 py-1 rounded-full">
              <WeatherIcon className="h-4 w-4 mr-1 text-neutral-medium" />
              <span className="text-sm">
                {weather.temperature}°C - {t(weather.condition.toLowerCase())}
              </span>
            </div>
          )}
        </div>
      </CardHeader>
      <CardContent>
        {isLoading ? (
          <FarmHealthSkeleton />
        ) : (
          <div>
            {/* Crop tabs */}
            <div className="flex space-x-2 mb-4 overflow-x-auto pb-1">
              {crops?.map(crop => (
                <button
                  key={crop.id}
                  onClick={() => setSelectedCropId(crop.id)}
                  className={`px-3 py-1.5 rounded-lg flex items-center text-sm whitespace-nowrap ${
                    (selectedCropId === crop.id || (!selectedCropId && crop.id === crops[0].id))
                      ? 'bg-primary text-white'
                      : 'bg-neutral-lightest text-neutral-dark hover:bg-neutral-light'
                  }`}
                >
                  <span className="font-medium">{crop.name}</span>
                  <Badge 
                    variant="outline" 
                    className={`ml-2 ${
                      (selectedCropId === crop.id || (!selectedCropId && crop.id === crops[0].id))
                        ? 'bg-white bg-opacity-20 text-white border-white'
                        : ''
                    }`}
                  >
                    {t(crop.status)}
                  </Badge>
                </button>
              ))}
            </div>
            
            {selectedCrop && (
              <div>
                {/* Crop info header */}
                <div className="flex justify-between items-start mb-4">
                  <div>
                    <h3 className="text-xl font-bold">{selectedCrop.name}</h3>
                    <div className="flex flex-wrap gap-2 mt-1">
                      <span className="text-sm text-neutral-medium">
                        {t("planted")}: {new Date(selectedCrop.plantedDate).toLocaleDateString('en-IN')}
                      </span>
                      <span className="text-sm text-neutral-medium">
                        {t("harvest")}: {new Date(selectedCrop.harvestDate).toLocaleDateString('en-IN')}
                      </span>
                      <span className="text-sm text-neutral-medium">
                        {t("season")}: {t(selectedCrop.season)}
                      </span>
                    </div>
                  </div>
                  <Button size="sm" variant="outline" className="flex items-center gap-1">
                    <InfoIcon className="h-4 w-4" />
                    {t("details")}
                  </Button>
                </div>
                
                {/* Health metrics */}
                <div className="space-y-4">
                  {/* Overall health */}
                  <div>
                    <div className="flex justify-between items-center mb-1">
                      <span className="font-medium">{t("overallHealth")}</span>
                      <span className={`text-sm font-semibold ${getColorClass(selectedCrop.currentHealth)}`}>
                        {selectedCrop.currentHealth}%
                      </span>
                    </div>
                    <div className="w-full bg-neutral-light rounded-full h-2">
                      <div 
                        className={`h-2 rounded-full ${getBarColorClass(selectedCrop.currentHealth)}`}
                        style={{ width: `${selectedCrop.currentHealth}%` }}
                      ></div>
                    </div>
                  </div>
                  
                  {/* Risk metrics */}
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <div className="flex justify-between items-center mb-1">
                        <span className="text-sm">{t("pestRisk")}</span>
                        <span className={`text-xs font-semibold ${getColorClass(100 - selectedCrop.pestRisk)}`}>
                          {selectedCrop.pestRisk}%
                        </span>
                      </div>
                      <div className="w-full bg-neutral-light rounded-full h-1.5">
                        <div 
                          className={`h-1.5 rounded-full ${getBarColorClass(100 - selectedCrop.pestRisk)}`}
                          style={{ width: `${selectedCrop.pestRisk}%` }}
                        ></div>
                      </div>
                    </div>
                    <div>
                      <div className="flex justify-between items-center mb-1">
                        <span className="text-sm">{t("diseaseRisk")}</span>
                        <span className={`text-xs font-semibold ${getColorClass(100 - selectedCrop.diseaseRisk)}`}>
                          {selectedCrop.diseaseRisk}%
                        </span>
                      </div>
                      <div className="w-full bg-neutral-light rounded-full h-1.5">
                        <div 
                          className={`h-1.5 rounded-full ${getBarColorClass(100 - selectedCrop.diseaseRisk)}`}
                          style={{ width: `${selectedCrop.diseaseRisk}%` }}
                        ></div>
                      </div>
                    </div>
                  </div>
                  
                  {/* Status metrics */}
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <div className="flex justify-between items-center mb-1">
                        <span className="text-sm">{t("waterStatus")}</span>
                        <span className={`text-xs font-semibold ${getColorClass(selectedCrop.waterStatus)}`}>
                          {selectedCrop.waterStatus}%
                        </span>
                      </div>
                      <div className="w-full bg-neutral-light rounded-full h-1.5">
                        <div 
                          className={`h-1.5 rounded-full ${getBarColorClass(selectedCrop.waterStatus)}`}
                          style={{ width: `${selectedCrop.waterStatus}%` }}
                        ></div>
                      </div>
                    </div>
                    <div>
                      <div className="flex justify-between items-center mb-1">
                        <span className="text-sm">{t("nutrientStatus")}</span>
                        <span className={`text-xs font-semibold ${getColorClass(selectedCrop.nutrientStatus)}`}>
                          {selectedCrop.nutrientStatus}%
                        </span>
                      </div>
                      <div className="w-full bg-neutral-light rounded-full h-1.5">
                        <div 
                          className={`h-1.5 rounded-full ${getBarColorClass(selectedCrop.nutrientStatus)}`}
                          style={{ width: `${selectedCrop.nutrientStatus}%` }}
                        ></div>
                      </div>
                    </div>
                  </div>
                  
                  {/* Notes */}
                  {selectedCrop.notes && (
                    <div className="mt-4 bg-neutral-lightest p-3 rounded-lg">
                      <h4 className="font-medium mb-1">{t("notes")}</h4>
                      <p className="text-sm text-neutral-medium">{selectedCrop.notes}</p>
                    </div>
                  )}
                </div>
              </div>
            )}
          </div>
        )}
      </CardContent>
    </Card>
  );
}

function getColorClass(value: number): string {
  if (value >= 80) return "text-success";
  if (value >= 60) return "text-warning";
  return "text-destructive";
}

function getBarColorClass(value: number): string {
  if (value >= 80) return "bg-success";
  if (value >= 60) return "bg-warning";
  return "bg-destructive";
}

function FarmHealthSkeleton() {
  return (
    <div>
      {/* Crop tabs skeleton */}
      <div className="flex space-x-2 mb-4 overflow-x-auto">
        {[1, 2, 3].map(i => (
          <Skeleton key={i} className="h-9 w-28 rounded-lg" />
        ))}
      </div>
      
      {/* Crop info header skeleton */}
      <div className="flex justify-between items-start mb-4">
        <div>
          <Skeleton className="h-7 w-36 mb-2" />
          <div className="flex flex-wrap gap-2">
            <Skeleton className="h-4 w-24" />
            <Skeleton className="h-4 w-24" />
            <Skeleton className="h-4 w-16" />
          </div>
        </div>
        <Skeleton className="h-9 w-24 rounded-md" />
      </div>
      
      {/* Health metrics skeleton */}
      <div className="space-y-4">
        <div>
          <div className="flex justify-between items-center mb-1">
            <Skeleton className="h-5 w-32" />
            <Skeleton className="h-4 w-12" />
          </div>
          <Skeleton className="h-2 w-full rounded-full" />
        </div>
        
        <div className="grid grid-cols-2 gap-4">
          {[1, 2, 3, 4].map(i => (
            <div key={i}>
              <div className="flex justify-between items-center mb-1">
                <Skeleton className="h-4 w-20" />
                <Skeleton className="h-3 w-8" />
              </div>
              <Skeleton className="h-1.5 w-full rounded-full" />
            </div>
          ))}
        </div>
        
        <Skeleton className="h-24 w-full rounded-lg mt-4" />
      </div>
    </div>
  );
}