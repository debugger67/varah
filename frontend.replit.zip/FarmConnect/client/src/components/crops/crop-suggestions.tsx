import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { 
  Card, 
  CardContent, 
  CardHeader, 
  CardTitle,
  CardDescription
} from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useLanguage } from "@/context/language-context";

interface CropRecommendation {
  id: number;
  name: string;
  variety: string;
  season: string;
  growingPeriod: string;
  waterRequirement: string;
  estimatedYield: string;
  marketDemand: string;
  profitPotential: string;
  imageUrl: string;
}

export default function CropSuggestions() {
  const { t } = useLanguage();
  const [season, setSeason] = useState<string>("all");
  
  // Get crop recommendation data
  const { data: cropRecommendations, isLoading } = useQuery({
    queryKey: ['/api/crop-recommendations', season],
    queryFn: async () => {
      const url = season === 'all' 
        ? '/api/crop-recommendations' 
        : `/api/crop-recommendations?season=${season}`;
      
      const response = await fetch(url);
      if (!response.ok) return [];
      return await response.json();
    }
  });

  // Seasons in India
  const seasons = ["all", "kharif", "rabi", "zaid"];

  return (
    <Card className="shadow-sm border-0">
      <CardHeader className="pb-2">
        <div className="flex justify-between items-center">
          <div>
            <CardTitle className="text-lg font-bold">{t("cropSuggestions")}</CardTitle>
            <CardDescription>{t("cropSuggestionsDescription")}</CardDescription>
          </div>
        </div>
      </CardHeader>
      <CardContent>
        <Tabs defaultValue="all" className="w-full" onValueChange={setSeason}>
          <TabsList className="grid grid-cols-4 mb-4">
            {seasons.map(s => (
              <TabsTrigger key={s} value={s} className="capitalize">
                {t(s === "all" ? "all" : s)}
              </TabsTrigger>
            ))}
          </TabsList>
          
          <TabsContent value={season}>
            {isLoading ? (
              <CropSuggestionsSkeleton />
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {cropRecommendations?.map((crop: CropRecommendation) => (
                  <div 
                    key={crop.id}
                    className="border border-neutral-light rounded-lg overflow-hidden hover:border-primary cursor-pointer transition-colors"
                  >
                    <div className="flex h-full">
                      {/* Crop Image */}
                      <div className="w-1/3 bg-neutral-lightest flex-shrink-0">
                        {crop.imageUrl ? (
                          <img 
                            src={crop.imageUrl} 
                            alt={crop.name} 
                            className="w-full h-full object-cover"
                          />
                        ) : (
                          <div className="w-full h-full flex items-center justify-center bg-primary bg-opacity-10">
                            <span className="text-primary text-lg font-bold">{crop.name.charAt(0)}</span>
                          </div>
                        )}
                      </div>
                      
                      {/* Crop Info */}
                      <div className="w-2/3 p-3">
                        <div className="flex justify-between items-start mb-2">
                          <div>
                            <h3 className="font-semibold">{crop.name}</h3>
                            <p className="text-sm text-neutral-medium">{crop.variety}</p>
                          </div>
                          <Badge>{t(crop.season.toLowerCase())}</Badge>
                        </div>
                        
                        <div className="grid grid-cols-2 gap-x-2 gap-y-1 mt-2 text-xs">
                          <div>
                            <span className="text-neutral-medium">{t("waterNeed")}:</span>
                            <span className="ml-1 font-medium">{crop.waterRequirement}</span>
                          </div>
                          <div>
                            <span className="text-neutral-medium">{t("growPeriod")}:</span>
                            <span className="ml-1 font-medium">{crop.growingPeriod}</span>
                          </div>
                          <div>
                            <span className="text-neutral-medium">{t("yield")}:</span>
                            <span className="ml-1 font-medium">{crop.estimatedYield}</span>
                          </div>
                          <div>
                            <span className="text-neutral-medium">{t("profit")}:</span>
                            <span className="ml-1 font-medium text-success">{crop.profitPotential}</span>
                          </div>
                        </div>
                        
                        <div className="mt-2 pt-2 border-t border-neutral-light">
                          <div className="flex items-center text-xs">
                            <span className="text-neutral-medium mr-2">{t("marketDemand")}:</span>
                            <div className="flex-1">
                              <div className="w-full bg-neutral-light rounded-full h-1.5">
                                <div 
                                  className="bg-primary h-1.5 rounded-full" 
                                  style={{ width: getDemandPercentage(crop.marketDemand) }}
                                ></div>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </TabsContent>
        </Tabs>
      </CardContent>
    </Card>
  );
}

// Helper function to convert demand level to percentage for progress bar
function getDemandPercentage(demandLevel: string): string {
  switch (demandLevel.toLowerCase()) {
    case "very high":
      return "90%";
    case "high":
      return "75%";
    case "medium":
      return "50%";
    case "low":
      return "25%";
    default:
      return "10%";
  }
}

function CropSuggestionsSkeleton() {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
      {[1, 2, 3, 4].map(i => (
        <div key={i} className="border border-neutral-light rounded-lg overflow-hidden">
          <div className="flex h-full">
            {/* Image skeleton */}
            <div className="w-1/3 bg-neutral-lightest flex-shrink-0">
              <Skeleton className="w-full h-full" />
            </div>
            
            {/* Content skeleton */}
            <div className="w-2/3 p-3">
              <div className="flex justify-between items-start mb-2">
                <div>
                  <Skeleton className="h-5 w-24 mb-1" />
                  <Skeleton className="h-4 w-16" />
                </div>
                <Skeleton className="h-6 w-16 rounded-full" />
              </div>
              
              <div className="grid grid-cols-2 gap-x-2 gap-y-1 mt-2">
                {[1, 2, 3, 4].map(j => (
                  <Skeleton key={j} className="h-4 w-full" />
                ))}
              </div>
              
              <div className="mt-2 pt-2 border-t border-neutral-light">
                <div className="flex items-center">
                  <Skeleton className="h-4 w-24 mr-2" />
                  <Skeleton className="h-2 w-full rounded-full" />
                </div>
              </div>
            </div>
          </div>
        </div>
      ))}
    </div>
  );
}