import { Link, useLocation } from "wouter";
import { useLanguage } from "@/context/language-context";
import { 
  HomeIcon, 
  FarmIcon, 
  MarketplaceIcon, 
  VideosIcon, 
  FinanceIcon,
  NotificationIcon
} from "@/lib/icons";

export default function BottomNavigation() {
  const [location] = useLocation();
  const { t } = useLanguage();

  const navItems = [
    { 
      path: "/", 
      icon: <HomeIcon className="h-6 w-6" />,
      label: t("home") 
    },
    { 
      path: "/farm", 
      icon: <FarmIcon className="h-6 w-6" />,
      label: t("myFarm") 
    },
    { 
      path: "/marketplace", 
      icon: <MarketplaceIcon className="h-6 w-6" />,
      label: t("marketplace") 
    },
    { 
      path: "/notifications", 
      icon: <NotificationIcon className="h-6 w-6" />,
      label: t("notifications") 
    },
    { 
      path: "/finances", 
      icon: <FinanceIcon className="h-6 w-6" />,
      label: t("finances") 
    },
  ];

  return (
    <nav className="md:hidden fixed bottom-0 left-0 right-0 bg-white bottom-nav z-40 px-2 py-2">
      <div className="flex justify-around">
        {navItems.map((item) => (
          <Link key={item.path} href={item.path}>
            <div className={`flex flex-col items-center px-3 py-1 ${
              location === item.path 
                ? 'text-primary' 
                : 'text-neutral-medium'
            }`}>
              {item.icon}
              <span className="text-xs mt-1">{item.label}</span>
            </div>
          </Link>
        ))}
      </div>
    </nav>
  );
}
