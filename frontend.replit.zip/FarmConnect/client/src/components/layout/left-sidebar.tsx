import { useLocation, Link } from "wouter";
import { 
  HomeIcon, 
  FarmIcon, 
  MarketplaceIcon, 
  FinanceIcon, 
  ConnectIcon, 
  VideosIcon, 
  NotificationIcon
} from "@/lib/icons";
import { useLanguage } from "@/context/language-context";
import WeatherWidget from "@/components/weather/weather-widget";

interface User {
  id: number;
  name: string;
  farmType: string;
  profileImage: string;
  profileCompleteness: number;
}

interface LeftSidebarProps {
  user?: User;
}

export default function LeftSidebar({ user }: LeftSidebarProps) {
  const [location] = useLocation();
  const { t } = useLanguage();

  const defaultUser = {
    id: 1,
    name: "Ravi Patel",
    farmType: "Wheat & Rice Farmer",
    profileImage: "https://images.unsplash.com/photo-1582440529534-d61bce629def",
    profileCompleteness: 85
  };

  const currentUser = user || defaultUser;

  const navItems = [
    { 
      path: "/", 
      icon: <HomeIcon className="h-5 w-5 mr-3 text-neutral-medium" />,
      label: t("home") 
    },
    { 
      path: "/farm", 
      icon: <FarmIcon className="h-5 w-5 mr-3 text-neutral-medium" />,
      label: t("myFarm") 
    },
    { 
      path: "/marketplace", 
      icon: <MarketplaceIcon className="h-5 w-5 mr-3 text-neutral-medium" />,
      label: t("marketplace") 
    },
    { 
      path: "/finances", 
      icon: <FinanceIcon className="h-5 w-5 mr-3 text-neutral-medium" />,
      label: t("finances") 
    },
    { 
      path: "/connect", 
      icon: <ConnectIcon className="h-5 w-5 mr-3 text-neutral-medium" />,
      label: t("connectNav") 
    },
    { 
      path: "/videos", 
      icon: <VideosIcon className="h-5 w-5 mr-3 text-neutral-medium" />,
      label: t("videos") 
    },
    { 
      path: "/notifications", 
      icon: <NotificationIcon className="h-5 w-5 mr-3 text-neutral-medium" />,
      label: t("notifications") 
    },
  ];

  return (
    <aside className="hidden md:block w-64 side-nav">
      <div className="bg-white rounded-xl shadow-sm p-4 mb-4">
        {/* User Profile Summary */}
        <div className="flex items-center space-x-3 mb-4">
          <img 
            src={currentUser.profileImage} 
            alt={currentUser.name} 
            className="w-16 h-16 rounded-full border-2 border-primary object-cover" 
          />
          <div>
            <h2 className="text-lg font-heading font-bold">{currentUser.name}</h2>
            <p className="text-sm text-neutral-medium">{currentUser.farmType}</p>
          </div>
        </div>
        
        {/* Profile Completeness */}
        <div className="border-t border-b border-neutral-light py-3 my-3">
          <div className="flex justify-between text-sm mb-1">
            <span>{t("profile")} {t("completeness")}</span>
            <span className="text-primary font-semibold">{currentUser.profileCompleteness}%</span>
          </div>
          <div className="w-full bg-neutral-light rounded-full h-2">
            <div 
              className="bg-primary h-2 rounded-full" 
              style={{ width: `${currentUser.profileCompleteness}%` }}
            ></div>
          </div>
        </div>
        
        {/* Navigation */}
        <div className="flex flex-col space-y-1">
          {navItems.map((item) => (
            <Link key={item.path} href={item.path}>
              <div 
                className={`flex items-center py-2 px-3 rounded-lg font-semibold cursor-pointer ${
                  location === item.path 
                    ? 'bg-primary/10 text-primary' 
                    : 'text-neutral-dark hover:bg-neutral-lightest'
                }`}
              >
                {item.icon}
                {item.label}
              </div>
            </Link>
          ))}
        </div>
      </div>
      
      {/* Weather Widget */}
      <WeatherWidget location="Amravati, Maharashtra" />
    </aside>
  );
}
