import { useLanguage } from "@/context/language-context";
import { MentorIcon, HeartIcon, MoneyIcon } from "@/lib/icons";
import MentorList from "@/components/mentors/mentor-list";
import FarmHealth from "@/components/farm/farm-health";
import FinancialSummary from "@/components/finance/financial-summary";

export default function RightSidebar() {
  const { t } = useLanguage();

  return (
    <aside className="hidden lg:block w-72 side-nav">
      {/* Mentors Section */}
      <div className="bg-white rounded-xl shadow-sm p-4 mb-4">
        <h3 className="text-lg font-heading font-bold mb-3 flex items-center">
          <MentorIcon className="h-5 w-5 mr-2 text-primary" />
          {t("connectWithMentors")}
        </h3>
        <MentorList />
        <button className="w-full mt-3 text-primary font-semibold text-sm">
          {t("viewAllMentors")}
        </button>
      </div>

      {/* Farm Health Section */}
      <div className="bg-white rounded-xl shadow-sm p-4 mb-4">
        <h3 className="text-lg font-heading font-bold mb-3 flex items-center">
          <HeartIcon className="h-5 w-5 mr-2 text-primary" />
          {t("yourFarmHealth")}
        </h3>
        <FarmHealth />
        <button className="w-full mt-3 border border-primary text-primary font-semibold rounded-lg py-2 text-sm">
          {t("viewCompleteFarmReport")}
        </button>
      </div>

      {/* Financial Summary */}
      <div className="bg-white rounded-xl shadow-sm p-4">
        <h3 className="text-lg font-heading font-bold mb-3 flex items-center">
          <MoneyIcon className="h-5 w-5 mr-2 text-primary" />
          {t("financialSummary")}
        </h3>
        <FinancialSummary />
        <button className="w-full mt-3 text-primary font-semibold text-sm">
          {t("viewFullFinancialReport")}
        </button>
      </div>
    </aside>
  );
}
