import { useState } from "react";
import { Link, useLocation } from "wouter";
import { SearchIcon } from "@/lib/icons";
import { useLanguage } from "@/context/language-context";
import PlantLogo from "@/components/branding/plant-logo";
import { 
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger
} from "@/components/ui/dropdown-menu";

interface HeaderProps {
  user?: {
    id: number;
    name: string;
    profileImage: string;
  };
}

export default function Header({ user }: HeaderProps) {
  const { t } = useLanguage();
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  
  const defaultUser = {
    id: 1,
    name: "Ravi Patel",
    profileImage: "https://images.unsplash.com/photo-1582440529534-d61bce629def"
  };
  
  const currentUser = user || defaultUser;

  return (
    <header className="bg-white shadow-md sticky top-0 z-40">
      <div className="container mx-auto flex items-center justify-between px-4 py-3">
        {/* Logo */}
        <div className="flex items-center">
          <Link href="/">
            <div className="flex items-center cursor-pointer">
              <div className="h-10 w-10 rounded mr-2 bg-white flex items-center justify-center">
                <PlantLogo variant="default" />
              </div>
              <h1 className="text-primary text-2xl font-heading font-bold">Varah</h1>
            </div>
          </Link>
        </div>

        {/* Search */}
        <div className="hidden md:flex items-center flex-grow mx-6 max-w-xl">
          <div className="relative w-full">
            <input 
              type="text" 
              placeholder={t("search")}
              className="w-full border border-neutral-light rounded-full py-2 px-4 pl-10 text-neutral-dark"
            />
            <SearchIcon className="h-5 w-5 absolute left-3 top-2.5 text-neutral-medium" />
          </div>
        </div>

        {/* Profile Menu (Desktop) */}
        <div className="hidden md:flex items-center">
          <DropdownMenu>
            <DropdownMenuTrigger className="focus:outline-none">
              <div className="flex items-center space-x-2">
                <img 
                  src={currentUser.profileImage} 
                  alt="Profile" 
                  className="w-10 h-10 rounded-full border-2 border-primary object-cover"
                />
                <span className="text-neutral-dark font-semibold hidden lg:inline">{currentUser.name}</span>
                <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-neutral-medium" viewBox="0 0 20 20" fill="currentColor">
                  <path fillRule="evenodd" d="M5.293 7.293a1 1 0 011.414 0L10 10.586l3.293-3.293a1 1 0 111.414 1.414l-4 4a1 1 0 01-1.414 0l-4-4a1 1 0 010-1.414z" clipRule="evenodd" />
                </svg>
              </div>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end">
              <DropdownMenuItem>
                <Link href="/profile">
                  <div className="w-full cursor-pointer">{t("profile")}</div>
                </Link>
              </DropdownMenuItem>
              <DropdownMenuItem>
                <Link href="/settings">
                  <div className="w-full cursor-pointer">{t("settings")}</div>
                </Link>
              </DropdownMenuItem>
              <DropdownMenuItem>
                <button className="w-full text-left">{t("logout")}</button>
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      </div>
    </header>
  );
}
