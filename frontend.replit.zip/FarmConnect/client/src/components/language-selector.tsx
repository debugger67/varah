import { useState } from "react";
import { useLanguage } from "@/context/language-context";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

type LanguageOption = {
  value: string;
  label: string;
  flag: string;
};

const languages: LanguageOption[] = [
  { value: "en", label: "English", flag: "🇺🇸" },
  { value: "hi", label: "हिंदी", flag: "🇮🇳" },
  { value: "te", label: "తెలుగు", flag: "🇮🇳" },
  { value: "ta", label: "தமிழ்", flag: "🇮🇳" },
  { value: "mr", label: "मराठी", flag: "🇮🇳" },
  { value: "pa", label: "ਪੰਜਾਬੀ", flag: "🇮🇳" },
];

export default function LanguageSelector() {
  const { language, setLanguage } = useLanguage();
  const [isOpen, setIsOpen] = useState(false);

  const handleLanguageChange = (value: string) => {
    setLanguage(value as any);
  };

  const selectedLanguage = languages.find(lang => lang.value === language);

  return (
    <div className="fixed top-4 right-4 z-50 bg-white rounded-full shadow-md p-2">
      <Select value={language} onValueChange={handleLanguageChange}>
        <SelectTrigger className="w-full border-none bg-transparent">
          <SelectValue>
            <span className="flex items-center">
              <span className="mr-2 text-lg">{selectedLanguage?.flag}</span>
              <span className="font-bold text-neutral-dark">{selectedLanguage?.label}</span>
            </span>
          </SelectValue>
        </SelectTrigger>
        <SelectContent>
          {languages.map((lang) => (
            <SelectItem key={lang.value} value={lang.value}>
              <span className="flex items-center">
                <span className="mr-2">{lang.flag}</span>
                <span>{lang.label}</span>
              </span>
            </SelectItem>
          ))}
        </SelectContent>
      </Select>
    </div>
  );
}
