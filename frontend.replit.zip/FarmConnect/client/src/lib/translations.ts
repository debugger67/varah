export const translations = {
  en: {
    // Common
    "language": "English",
    "home": "Home",
    "myFarm": "My Farm",
    "marketplace": "Marketplace",
    "finances": "Finances",
    "connectNav": "Connect",
    "videos": "Videos",
    "notifications": "Notifications",
    "profile": "Profile",
    "settings": "Settings",
    "logout": "Logout",
    "search": "Search for crops, farmers, markets...",
    
    // Weather
    "weatherAlert": "Weather Alert",
    "expectedRain": "Light rain expected tomorrow. Consider postponing pesticide application.",
    
    // Marketplace
    "trendingMarkets": "Trending Markets",
    "highDemand": "High Demand",
    "mediumDemand": "Medium Demand",
    "lowDemand": "Low Demand",
    "topCrop": "Top Crop",
    "currentPrice": "Current Price",
    "suggestedForCrops": "Suggested for Your Crops",
    "readyForHarvest": "Ready for harvest in 2 weeks",
    "transportOptions": "Transport Options",
    "findBuyers": "Find Buyers",
    "priceComparison": "Price Comparison",
    "market": "Market",
    "distance": "Distance",
    "price": "Price/Quintal",
    "demand": "Demand",
    "transportCost": "Transport Cost",
    "netProfit": "Net Profit",
    "bestMatch": "Best Match",
    "transportAndPooling": "Transport & Pooling",
    "availableTransporters": "Available Transporters",
    "capacity": "Capacity",
    "viewAllTransporters": "View All Transporters",
    "poolingOpportunities": "Pooling Opportunities",
    "departing": "Departing",
    "save": "Save",
    "joinPool": "Join Pool",
    "startNewPool": "Start New Pool",
    "allMarkets": "All Markets",
    "localDistrict": "Local/District",
    "state": "State",
    "national": "National",
    "international": "International",
    "listCrop": "List Crop",
    "upFromLastWeek": "Up {percent}% from last week",
    "downFromLastWeek": "Down {percent}% from last week",
    "viewDetails": "View Details",
    
    // Crop Suggestions
    "recommendedCrops": "Recommended Crops",
    "rabiSeasonInfo": "Based on your soil quality and previous crops, we've identified these high-yield options for the upcoming Rabi season.",
    "rabiSeason": "Rabi Season",
    "growingPeriod": "Growing Period",
    "waterRequirement": "Water Requirement",
    "estYield": "Est. Yield",
    "marketDemand": "Market Demand",
    "highProfit": "High Profit",
    "mediumProfit": "Medium Profit",
    "low": "Low",
    "medium": "Medium",
    "high": "High",
    "viewDetailedGuide": "View Detailed Guide",
    "viewAllCropRecommendations": "View All Crop Recommendations",
    
    // Videos
    "latestVideos": "Latest Videos",
    "viewAll": "View All",
    "views": "views",
    "daysAgo": "days ago",
    
    // Mentors
    "connectWithMentors": "Connect with Mentors",
    "online": "Online",
    "connectButton": "Connect",
    "message": "Message",
    "viewAllMentors": "View All Mentors",
    
    // Farm Health
    "yourFarmHealth": "Your Farm Health",
    "healthy": "Healthy",
    "needsAttention": "Needs Attention",
    "soilHealth": "Soil Health",
    "waterContent": "Water Content",
    "pestControl": "Pest Control",
    "pestAlert": "Alert: Pest detected in rice field. Connect with a mentor for advice.",
    "viewCompleteFarmReport": "View Complete Farm Report",
    
    // Financial Summary
    "financialSummary": "Financial Summary",
    "totalRevenue": "Total revenue this season",
    "income": "Income",
    "expenses": "Expenses",
    "recentTransactions": "Recent Transactions",
    "viewFullFinancialReport": "View Full Financial Report"
  },
  
  hi: {
    // Common
    "language": "हिंदी",
    "home": "होम",
    "myFarm": "मेरा खेत",
    "marketplace": "बाज़ार",
    "finances": "वित्त",
    "connectNav": "जुड़ें",
    "videos": "वीडियो",
    "notifications": "सूचनाएं",
    "profile": "प्रोफाइल",
    "settings": "सेटिंग्स",
    "logout": "लॉगआउट",
    "search": "फसलों, किसानों, बाज़ारों के लिए खोजें...",
    
    // Weather
    "weatherAlert": "मौसम अलर्ट",
    "expectedRain": "कल हल्की बारिश की संभावना है। कीटनाशक छिड़काव स्थगित करने पर विचार करें।",
    
    // Marketplace
    "trendingMarkets": "लोकप्रिय बाज़ार",
    "highDemand": "उच्च मांग",
    "mediumDemand": "मध्यम मांग",
    "lowDemand": "कम मांग",
    "topCrop": "शीर्ष फसल",
    "currentPrice": "वर्तमान मूल्य",
    "suggestedForCrops": "आपकी फसलों के लिए सुझाव",
    "readyForHarvest": "2 सप्ताह में कटाई के लिए तैयार",
    "transportOptions": "परिवहन विकल्प",
    "findBuyers": "खरीदार खोजें",
    "priceComparison": "मूल्य तुलना",
    "market": "बाज़ार",
    "distance": "दूरी",
    "price": "मूल्य/क्विंटल",
    "demand": "मांग",
    "transportCost": "परिवहन लागत",
    "netProfit": "शुद्ध लाभ",
    "bestMatch": "सर्वोत्तम मिलान",
    "transportAndPooling": "परिवहन और पूलिंग",
    "availableTransporters": "उपलब्ध वाहक",
    "capacity": "क्षमता",
    "viewAllTransporters": "सभी वाहक देखें",
    "poolingOpportunities": "पूलिंग अवसर",
    "departing": "प्रस्थान",
    "save": "बचत",
    "joinPool": "पूल में शामिल हों",
    "startNewPool": "नया पूल शुरू करें",
    "allMarkets": "सभी बाज़ार",
    "localDistrict": "स्थानीय/जिला",
    "state": "राज्य",
    "national": "राष्ट्रीय",
    "international": "अंतर्राष्ट्रीय",
    "listCrop": "फसल सूचीबद्ध करें",
    "upFromLastWeek": "पिछले सप्ताह से {percent}% अधिक",
    "downFromLastWeek": "पिछले सप्ताह से {percent}% कम",
    "viewDetails": "विवरण देखें",
    
    // Crop Suggestions
    "recommendedCrops": "अनुशंसित फसलें",
    "rabiSeasonInfo": "आपकी मिट्टी की गुणवत्ता और पिछली फसलों के आधार पर, हमने आगामी रबी मौसम के लिए उच्च उपज वाले विकल्प चिह्नित किए हैं।",
    "rabiSeason": "रबी मौसम",
    "growingPeriod": "विकास अवधि",
    "waterRequirement": "पानी की आवश्यकता",
    "estYield": "अनुमानित उपज",
    "marketDemand": "बाज़ार मांग",
    "highProfit": "उच्च लाभ",
    "mediumProfit": "मध्यम लाभ",
    "low": "कम",
    "medium": "मध्यम",
    "high": "उच्च",
    "viewDetailedGuide": "विस्तृत गाइड देखें",
    "viewAllCropRecommendations": "सभी फसल अनुशंसाएं देखें",
    
    // Videos
    "latestVideos": "नवीनतम वीडियो",
    "viewAll": "सभी देखें",
    "views": "दृश्य",
    "daysAgo": "दिन पहले",
    
    // Mentors
    "connectWithMentors": "मेंटर्स से जुड़ें",
    "online": "ऑनलाइन",
    "connectButton": "जुड़ें",
    "message": "संदेश",
    "viewAllMentors": "सभी मेंटर्स देखें",
    
    // Farm Health
    "yourFarmHealth": "आपके खेत का स्वास्थ्य",
    "healthy": "स्वस्थ",
    "needsAttention": "ध्यान देने की आवश्यकता है",
    "soilHealth": "मिट्टी का स्वास्थ्य",
    "waterContent": "पानी की मात्रा",
    "pestControl": "कीट नियंत्रण",
    "pestAlert": "अलर्ट: धान के खेत में कीट का पता चला है। सलाह के लिए मेंटर से जुड़ें।",
    "viewCompleteFarmReport": "पूरी खेत रिपोर्ट देखें",
    
    // Financial Summary
    "financialSummary": "वित्तीय सारांश",
    "totalRevenue": "इस मौसम का कुल राजस्व",
    "income": "आय",
    "expenses": "व्यय",
    "recentTransactions": "हाल के लेनदेन",
    "viewFullFinancialReport": "पूरी वित्तीय रिपोर्ट देखें"
  },
  
  te: {
    // Common
    "language": "తెలుగు",
    "home": "హోమ్",
    "myFarm": "నా వ్యవసాయం",
    "marketplace": "మార్కెట్",
    "finances": "ఆర్థిక",
    "connectNav": "కనెక్ట్",
    "videos": "వీడియోలు",
    "notifications": "నోటిఫికేషన్స్",
    "profile": "ప్రొఫైల్",
    "settings": "సెట్టింగ్స్",
    "logout": "లాగ్అవుట్",
    "search": "పంటలు, రైతులు, మార్కెట్ల కోసం శోధించండి...",
    
    // Weather
    "weatherAlert": "వాతావరణ హెచ్చరిక",
    "expectedRain": "రేపు తేలికపాటి వర్షం పడే అవకాశం ఉంది. కీటకనాశినులు వేయడం వాయిదా వేయడాన్ని పరిగణించండి.",
    
    // Marketplace
    "trendingMarkets": "ట్రెండింగ్ మార్కెట్లు",
    "highDemand": "అధిక డిమాండ్",
    "mediumDemand": "మధ్యస్థ డిమాండ్",
    "lowDemand": "తక్కువ డిమాండ్",
    "topCrop": "టాప్ పంట",
    "currentPrice": "ప్రస్తుత ధర",
    "suggestedForCrops": "మీ పంటల కోసం సూచించబడినవి",
    "readyForHarvest": "2 వారాల్లో కోతకు సిద్ధంగా ఉంది",
    "transportOptions": "రవాణా ఎంపికలు",
    "findBuyers": "కొనుగోలుదారులను కనుగొనండి",
    "priceComparison": "ధర పోలిక",
    "market": "మార్కెట్",
    "distance": "దూరం",
    "price": "ధర/క్వింటాల్",
    "demand": "డిమాండ్",
    "transportCost": "రవాణా ఖర్చు",
    "netProfit": "నికర లాభం",
    "bestMatch": "ఉత్తమ మ్యాచ్",
    
    // Farm Health
    "yourFarmHealth": "మీ వ్యవసాయ ఆరోగ్యం",
    "healthy": "ఆరోగ్యకరమైన",
    "needsAttention": "శ్రద్ధ అవసరం",
    "soilHealth": "నేల ఆరోగ్యం",
    "waterContent": "నీటి పరిమాణం",
    "pestControl": "పురుగు నియంత్రణ",
    
    // Financial Summary
    "financialSummary": "ఆర్థిక సారాంశం",
    "totalRevenue": "ఈ సీజన్‌లో మొత్తం ఆదాయం",
    "income": "ఆదాయం",
    "expenses": "ఖర్చులు",
    "recentTransactions": "ఇటీవలి లావాదేవీలు"
  },
  
  ta: {
    // Common
    "language": "தமிழ்",
    "home": "முகப்பு",
    "myFarm": "எனது பண்ணை",
    "marketplace": "சந்தை",
    "finances": "நிதி",
    "connectNav": "இணைக்க",
    "videos": "வீடியோக்கள்",
    "notifications": "அறிவிப்புகள்",
    "profile": "சுயவிவரம்",
    "settings": "அமைப்புகள்",
    "logout": "வெளியேறு",
    "search": "பயிர்கள், விவசாயிகள், சந்தைகள் தேடல்...",
    
    // Weather
    "weatherAlert": "வானிலை எச்சரிக்கை",
    "expectedRain": "நாளை லேசான மழை எதிர்பார்க்கப்படுகிறது. பூச்சிக்கொல்லி தெளிப்பதை ஒத்திவைக்க பரிசீலிக்கவும்.",
    
    // Marketplace
    "trendingMarkets": "டிரெண்டிங் சந்தைகள்",
    "highDemand": "அதிக தேவை",
    "mediumDemand": "நடுத்தர தேவை",
    "lowDemand": "குறைந்த தேவை",
    "topCrop": "சிறந்த பயிர்",
    "currentPrice": "தற்போதைய விலை",
    "suggestedForCrops": "உங்கள் பயிர்களுக்கு பரிந்துரைக்கப்பட்டது",
    "readyForHarvest": "2 வாரங்களில் அறுவடைக்கு தயாராகும்",
    "transportOptions": "போக்குவரத்து விருப்பங்கள்",
    "findBuyers": "வாங்குபவர்களைக் கண்டறியவும்",
    "priceComparison": "விலை ஒப்பீடு",
    "market": "சந்தை",
    "distance": "தூரம்",
    "price": "விலை/குவிண்டால்",
    "demand": "தேவை",
    "transportCost": "போக்குவரத்து செலவு",
    "netProfit": "நிகர லாபம்",
    "bestMatch": "சிறந்த பொருத்தம்",
    
    // Farm Health
    "yourFarmHealth": "உங்கள் பண்ணை ஆரோக்கியம்",
    "healthy": "ஆரோக்கியமான",
    "needsAttention": "கவனம் தேவை",
    "soilHealth": "மண் ஆரோக்கியம்",
    "waterContent": "நீர் அளவு",
    "pestControl": "பூச்சி கட்டுப்பாடு",
    
    // Financial Summary
    "financialSummary": "நிதி சுருக்கம்",
    "totalRevenue": "இந்த பருவத்தில் மொத்த வருவாய்",
    "income": "வருமானம்",
    "expenses": "செலவுகள்",
    "recentTransactions": "சமீபத்திய பரிவர்த்தனைகள்"
  },
  
  mr: {
    // Common
    "language": "मराठी",
    "home": "होम",
    "myFarm": "माझे शेत",
    "marketplace": "बाजार",
    "finances": "वित्त",
    "connectNav": "कनेक्ट",
    "videos": "व्हिडिओ",
    "notifications": "सूचना",
    "profile": "प्रोफाइल",
    "settings": "सेटिंग्ज",
    "logout": "लॉगआउट",
    "search": "पिके, शेतकरी, बाजारपेठा शोधा...",
    
    // Weather
    "weatherAlert": "हवामान अलर्ट",
    "expectedRain": "उद्या हलक्या पावसाची शक्यता आहे. कीटकनाशक फवारणी पुढे ढकलण्याचा विचार करा.",
    
    // Marketplace
    "trendingMarkets": "ट्रेंडिंग बाजार",
    "highDemand": "जास्त मागणी",
    "mediumDemand": "मध्यम मागणी",
    "lowDemand": "कमी मागणी",
    "topCrop": "टॉप पीक",
    "currentPrice": "वर्तमान किंमत",
    "suggestedForCrops": "तुमच्या पिकांसाठी सूचित",
    "readyForHarvest": "2 आठवड्यांत कापणीसाठी तयार",
    "transportOptions": "वाहतूक पर्याय",
    "findBuyers": "खरेदीदार शोधा",
    "priceComparison": "किंमत तुलना",
    "market": "बाजार",
    "distance": "अंतर",
    "price": "किंमत/क्विंटल",
    "demand": "मागणी",
    "transportCost": "वाहतूक खर्च",
    "netProfit": "निव्वळ नफा",
    "bestMatch": "सर्वोत्तम मिलान",
    
    // Farm Health
    "yourFarmHealth": "तुमच्या शेताचे आरोग्य",
    "healthy": "निरोगी",
    "needsAttention": "लक्ष देण्याची गरज आहे",
    "soilHealth": "माती आरोग्य",
    "waterContent": "पाणी सामग्री",
    "pestControl": "कीड नियंत्रण",
    
    // Financial Summary
    "financialSummary": "आर्थिक सारांश",
    "totalRevenue": "या हंगामातील एकूण महसूल",
    "income": "उत्पन्न",
    "expenses": "खर्च",
    "recentTransactions": "अलीकडील व्यवहार"
  },
  
  pa: {
    // Common
    "language": "ਪੰਜਾਬੀ",
    "home": "ਹੋਮ",
    "myFarm": "ਮੇਰੀ ਖੇਤੀ",
    "marketplace": "ਬਾਜ਼ਾਰ",
    "finances": "ਵਿੱਤ",
    "connectNav": "ਕਨੈਕਟ",
    "videos": "ਵੀਡੀਓ",
    "notifications": "ਸੂਚਨਾਵਾਂ",
    "profile": "ਪ੍ਰੋਫਾਈਲ",
    "settings": "ਸੈਟਿੰਗਾਂ",
    "logout": "ਲੌਗਆਉਟ",
    "search": "ਫਸਲਾਂ, ਕਿਸਾਨਾਂ, ਬਾਜ਼ਾਰਾਂ ਲਈ ਖੋਜ...",
    
    // Weather
    "weatherAlert": "ਮੌਸਮ ਅਲਰਟ",
    "expectedRain": "ਕੱਲ੍ਹ ਹਲਕੀ ਬਾਰਿਸ਼ ਦੀ ਸੰਭਾਵਨਾ ਹੈ। ਕੀਟਨਾਸ਼ਕ ਦੇ ਛਿੜਕਾਅ ਨੂੰ ਮੁਲਤਵੀ ਕਰਨ 'ਤੇ ਵਿਚਾਰ ਕਰੋ।",
    
    // Marketplace
    "trendingMarkets": "ਟ੍ਰੈਂਡਿੰਗ ਬਾਜ਼ਾਰ",
    "highDemand": "ਉੱਚ ਮੰਗ",
    "mediumDemand": "ਦਰਮਿਆਨੀ ਮੰਗ",
    "lowDemand": "ਘੱਟ ਮੰਗ",
    "topCrop": "ਟਾਪ ਫਸਲ",
    "currentPrice": "ਮੌਜੂਦਾ ਕੀਮਤ",
    "suggestedForCrops": "ਤੁਹਾਡੀਆਂ ਫਸਲਾਂ ਲਈ ਸੁਝਾਅ",
    "readyForHarvest": "2 ਹਫ਼ਤਿਆਂ ਵਿੱਚ ਵਾਢੀ ਲਈ ਤਿਆਰ",
    "transportOptions": "ਟ੍ਰਾਂਸਪੋਰਟ ਵਿਕਲਪ",
    "findBuyers": "ਖਰੀਦਦਾਰ ਲੱਭੋ",
    "priceComparison": "ਕੀਮਤ ਤੁਲਨਾ",
    "market": "ਬਾਜ਼ਾਰ",
    "distance": "ਦੂਰੀ",
    "price": "ਕੀਮਤ/ਕੁਇੰਟਲ",
    "demand": "ਮੰਗ",
    "transportCost": "ਟ੍ਰਾਂਸਪੋਰਟ ਲਾਗਤ",
    "netProfit": "ਸ਼ੁੱਧ ਲਾਭ",
    "bestMatch": "ਸਭ ਤੋਂ ਵਧੀਆ ਮੇਲ",
    
    // Farm Health
    "yourFarmHealth": "ਤੁਹਾਡੀ ਖੇਤੀ ਦੀ ਸਿਹਤ",
    "healthy": "ਸਿਹਤਮੰਦ",
    "needsAttention": "ਧਿਆਨ ਦੀ ਲੋੜ ਹੈ",
    "soilHealth": "ਮਿੱਟੀ ਦੀ ਸਿਹਤ",
    "waterContent": "ਪਾਣੀ ਦੀ ਮਾਤਰਾ",
    "pestControl": "ਕੀੜੇ ਨਿਯੰਤਰਣ",
    
    // Financial Summary
    "financialSummary": "ਵਿੱਤੀ ਸੰਖੇਪ",
    "totalRevenue": "ਇਸ ਮੌਸਮ ਵਿੱਚ ਕੁੱਲ ਮਾਲੀਆ",
    "income": "ਆਮਦਨ",
    "expenses": "ਖਰਚੇ",
    "recentTransactions": "ਹਾਲੀਆ ਲੈਣ-ਦੇਣ"
  }
};
