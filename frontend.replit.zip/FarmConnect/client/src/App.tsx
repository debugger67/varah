import { Switch, Route } from "wouter";
import { QueryClientProvider } from "@tanstack/react-query";
import { queryClient } from "./lib/queryClient";
import { Toaster } from "@/components/ui/toaster";
import NotFound from "@/pages/not-found";
import Dashboard from "@/pages/dashboard";
import Marketplace from "@/pages/marketplace";
import Farm from "@/pages/farm";
import Finances from "@/pages/finances";
import Videos from "@/pages/videos";
import Connect from "@/pages/connect";
import Notifications from "@/pages/notifications";
import { LanguageProvider } from "./context/language-context";
import LanguageSelector from "./components/language-selector";

function Router() {
  return (
    <Switch>
      <Route path="/" component={Dashboard} />
      <Route path="/marketplace" component={Marketplace} />
      <Route path="/farm" component={Farm} />
      <Route path="/finances" component={Finances} />
      <Route path="/videos" component={Videos} />
      <Route path="/connect" component={Connect} />
      <Route path="/notifications" component={Notifications} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <LanguageProvider>
      <QueryClientProvider client={queryClient}>
        <LanguageSelector />
        <Router />
        <Toaster />
      </QueryClientProvider>
    </LanguageProvider>
  );
}

export default App;
