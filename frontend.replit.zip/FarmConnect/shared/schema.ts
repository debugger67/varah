import { pgTable, text, serial, integer, boolean, timestamp, real, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  name: text("name").notNull(),
  profileImage: text("profile_image"),
  farmType: text("farm_type"),
  location: text("location"),
  state: text("state"),
  district: text("district"),
  profileCompleteness: integer("profile_completeness").default(0),
  language: text("language").default("en"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const farms = pgTable("farms", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id),
  name: text("name").notNull(),
  location: text("location"),
  size: real("size"), // in hectares
  soilType: text("soil_type"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const crops = pgTable("crops", {
  id: serial("id").primaryKey(),
  farmId: integer("farm_id").notNull().references(() => farms.id),
  name: text("name").notNull(),
  variety: text("variety"),
  status: text("status").notNull(),
  plantedDate: timestamp("planted_date"),
  harvestDate: timestamp("harvest_date"),
  season: text("season"), // rabi, kharif, zaid
  healthStatus: integer("health_status").default(100),
  soilHealth: integer("soil_health").default(100),
  waterContent: integer("water_content").default(100),
  pestControl: integer("pest_control").default(100),
  notes: text("notes"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const markets = pgTable("markets", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  location: text("location").notNull(),
  state: text("state").notNull(),
  district: text("district"),
  type: text("type").notNull(), // local/district, state, national, international
  demandLevel: text("demand_level").notNull(), // high, medium, low
  createdAt: timestamp("created_at").defaultNow(),
});

export const cropMarkets = pgTable("crop_markets", {
  id: serial("id").primaryKey(),
  marketId: integer("market_id").notNull().references(() => markets.id),
  cropName: text("crop_name").notNull(),
  price: integer("price").notNull(), // price per quintal
  priceChange: integer("price_change").default(0), // percentage change
  availability: text("availability").default("available"),
  demandLevel: text("demand_level").notNull(), // high, medium, low
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const transporters = pgTable("transporters", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  capacity: integer("capacity").notNull(), // in tonnes
  ratePerKm: integer("rate_per_km").notNull(),
  contact: text("contact"),
  location: text("location"),
  available: boolean("available").default(true),
  createdAt: timestamp("created_at").defaultNow(),
});

export const transportPools = pgTable("transport_pools", {
  id: serial("id").primaryKey(),
  destination: text("destination").notNull(),
  departureDate: timestamp("departure_date").notNull(),
  cropType: text("crop_type").notNull(),
  capacity: integer("capacity").notNull(), // total capacity
  filledCapacity: integer("filled_capacity").default(0),
  savingsPercentage: integer("savings_percentage").notNull(),
  createdAt: timestamp("created_at").defaultNow(),
});

export const poolMembers = pgTable("pool_members", {
  id: serial("id").primaryKey(),
  poolId: integer("pool_id").notNull().references(() => transportPools.id),
  userId: integer("user_id").notNull().references(() => users.id),
  contribution: integer("contribution").notNull(), // in tonnes
  createdAt: timestamp("created_at").defaultNow(),
});

export const cropRecommendations = pgTable("crop_recommendations", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  variety: text("variety").notNull(),
  season: text("season").notNull(), // rabi, kharif, zaid
  growingPeriod: text("growing_period").notNull(),
  waterRequirement: text("water_requirement").notNull(), // low, medium, high
  estimatedYield: text("estimated_yield").notNull(),
  marketDemand: text("market_demand").notNull(), // high, medium, low
  profitPotential: text("profit_potential").notNull(), // high, medium, low
  imageUrl: text("image_url"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const mentors = pgTable("mentors", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  specialization: text("specialization").notNull(),
  organization: text("organization"),
  qualification: text("qualification"),
  profileImage: text("profile_image"),
  isOnline: boolean("is_online").default(false),
  createdAt: timestamp("created_at").defaultNow(),
});

export const videos = pgTable("videos", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  authorId: integer("author_id").notNull().references(() => users.id),
  authorName: text("author_name").notNull(),
  authorRole: text("author_role"),
  thumbnailUrl: text("thumbnail_url"),
  duration: text("duration").notNull(),
  views: integer("views").default(0),
  uploadedAt: timestamp("uploaded_at").defaultNow(),
});

export const financialTransactions = pgTable("financial_transactions", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id),
  transactionType: text("transaction_type").notNull(), // income, expense
  category: text("category").notNull(),
  amount: integer("amount").notNull(),
  description: text("description"),
  date: timestamp("date").defaultNow(),
});

export const weatherAlerts = pgTable("weather_alerts", {
  id: serial("id").primaryKey(),
  location: text("location").notNull(),
  alert: text("alert").notNull(),
  severity: text("severity").notNull(), // info, warning, danger
  date: timestamp("date").defaultNow(),
});

// Insert Schemas
export const insertUserSchema = createInsertSchema(users).omit({ id: true, profileCompleteness: true, createdAt: true });
export const insertFarmSchema = createInsertSchema(farms).omit({ id: true, createdAt: true });
export const insertCropSchema = createInsertSchema(crops).omit({ id: true, createdAt: true });
export const insertMarketSchema = createInsertSchema(markets).omit({ id: true, createdAt: true });
export const insertCropMarketSchema = createInsertSchema(cropMarkets).omit({ id: true, updatedAt: true });
export const insertTransporterSchema = createInsertSchema(transporters).omit({ id: true, createdAt: true });
export const insertTransportPoolSchema = createInsertSchema(transportPools).omit({ id: true, filledCapacity: true, createdAt: true });
export const insertPoolMemberSchema = createInsertSchema(poolMembers).omit({ id: true, createdAt: true });
export const insertCropRecommendationSchema = createInsertSchema(cropRecommendations).omit({ id: true, createdAt: true });
export const insertMentorSchema = createInsertSchema(mentors).omit({ id: true, isOnline: true, createdAt: true });
export const insertVideoSchema = createInsertSchema(videos).omit({ id: true, views: true, uploadedAt: true });
export const insertFinancialTransactionSchema = createInsertSchema(financialTransactions).omit({ id: true, date: true });
export const insertWeatherAlertSchema = createInsertSchema(weatherAlerts).omit({ id: true, date: true });

// Types
export type User = typeof users.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;

export type Farm = typeof farms.$inferSelect;
export type InsertFarm = z.infer<typeof insertFarmSchema>;

export type Crop = typeof crops.$inferSelect;
export type InsertCrop = z.infer<typeof insertCropSchema>;

export type Market = typeof markets.$inferSelect;
export type InsertMarket = z.infer<typeof insertMarketSchema>;

export type CropMarket = typeof cropMarkets.$inferSelect;
export type InsertCropMarket = z.infer<typeof insertCropMarketSchema>;

export type Transporter = typeof transporters.$inferSelect;
export type InsertTransporter = z.infer<typeof insertTransporterSchema>;

export type TransportPool = typeof transportPools.$inferSelect;
export type InsertTransportPool = z.infer<typeof insertTransportPoolSchema>;

export type PoolMember = typeof poolMembers.$inferSelect;
export type InsertPoolMember = z.infer<typeof insertPoolMemberSchema>;

export type CropRecommendation = typeof cropRecommendations.$inferSelect;
export type InsertCropRecommendation = z.infer<typeof insertCropRecommendationSchema>;

export type Mentor = typeof mentors.$inferSelect;
export type InsertMentor = z.infer<typeof insertMentorSchema>;

export type Video = typeof videos.$inferSelect;
export type InsertVideo = z.infer<typeof insertVideoSchema>;

export type FinancialTransaction = typeof financialTransactions.$inferSelect;
export type InsertFinancialTransaction = z.infer<typeof insertFinancialTransactionSchema>;

export type WeatherAlert = typeof weatherAlerts.$inferSelect;
export type InsertWeatherAlert = z.infer<typeof insertWeatherAlertSchema>;
